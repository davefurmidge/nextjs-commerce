"use strict";
(() => {
var exports = {};
exports.id = 102;
exports.ids = [102];
exports.modules = {

/***/ 5850:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _commerce_)
});

// EXTERNAL MODULE: ../node_modules/.pnpm/zod@3.19.1/node_modules/zod/lib/index.mjs
var lib = __webpack_require__(877);
;// CONCATENATED MODULE: ../packages/commerce/dist/utils/errors.js
class CommerceError extends Error {
    constructor({ message , code , errors  }){
        const error = message ? {
            message,
            ...code ? {
                code
            } : {}
        } : errors[0];
        super(error.message);
        this.errors = message ? [
            error
        ] : errors;
        if (error.code) this.code = error.code;
    }
}
// Used for errors that come from a bad implementation of the hooks
class ValidationError extends (/* unused pure expression or super */ null && (CommerceError)) {
    constructor(options){
        super(options);
        this.code = "validation_error";
    }
}
class FetcherError extends CommerceError {
    constructor(options){
        super(options);
        this.status = options.status;
    }
}

;// CONCATENATED MODULE: ../packages/commerce/dist/api/utils/errors.js


class CommerceAPIResponseError extends Error {
    constructor(msg, res, data){
        super(msg);
        this.name = "CommerceApiError";
        this.status = res.status;
        this.res = res;
        this.data = data;
    }
}
class CommerceAPIError extends Error {
    constructor(msg, options){
        super(msg);
        this.name = "CommerceApiError";
        this.status = (options == null ? void 0 : options.status) || 500;
        this.code = (options == null ? void 0 : options.code) || "api_error";
    }
}
class CommerceNetworkError extends Error {
    constructor(msg){
        super(msg);
        this.name = "CommerceNetworkError";
    }
}
const normalizeZodIssues = (issues)=>issues.map(({ path , message  })=>path.length ? `${message} at "${path.join(".")}" field` : message);
const getOperationError = (operation, error)=>{
    if (error instanceof lib/* ZodError */.jm) {
        return new CommerceError({
            code: "SCHEMA_VALIDATION_ERROR",
            message: `Validation ${error.issues.length === 1 ? "error" : "errors"} at "${operation}" operation: \n` + normalizeZodIssues(error.issues).join("\n")
        });
    }
    return error;
};
const normalizeApiError = (error, req)=>{
    if (error instanceof CommerceAPIResponseError && error.res) {
        return error.res;
    }
    (req == null ? void 0 : req.url) && console.log(req.url);
    if (error instanceof lib/* ZodError */.jm) {
        const message = "Validation error, please check the input data!";
        const errors = normalizeZodIssues(error.issues).map((message)=>({
                message
            }));
        console.error(`${message}\n${errors.map((e)=>e.message).join("\n")}`);
        return {
            status: 400,
            data: null,
            errors
        };
    }
    console.error(error);
    if (error instanceof CommerceAPIError) {
        return {
            errors: [
                {
                    message: error.message,
                    code: error.code
                }, 
            ],
            status: error.status
        };
    }
    return {
        data: null,
        errors: [
            {
                message: "An unexpected error ocurred"
            }
        ]
    };
};

;// CONCATENATED MODULE: ../packages/commerce/dist/schemas/page.js

const pageSchema = lib.z.object({
    id: lib.z.string(),
    name: lib.z.string(),
    url: lib.z.string().startsWith("/").optional(),
    body: lib.z.string(),
    is_visible: lib.z.boolean().optional(),
    sort_order: lib.z.number().optional()
});
const pagesPathsSchema = lib.z.array(lib.z.object({
    page: lib.z.object({
        path: lib.z.string().startsWith("/")
    })
}));

;// CONCATENATED MODULE: ../packages/commerce/dist/schemas/site.js

const siteInfoSchema = lib.z.object({
    categories: lib.z.array(lib.z.object({
        id: lib.z.string(),
        name: lib.z.string(),
        path: lib.z.string().startsWith("/")
    })),
    brands: lib.z.array(lib.z.object({
        id: lib.z.string(),
        name: lib.z.string(),
        path: lib.z.string().startsWith("/")
    }))
});

;// CONCATENATED MODULE: ../packages/commerce/dist/schemas/product.js

const productPriceSchema = lib.z.object({
    value: lib.z.number(),
    currencyCode: lib.z.string().max(3).optional(),
    retailPrice: lib.z.number().optional()
});
const productOptionSchema = lib.z.object({
    id: lib.z.string(),
    displayName: lib.z.string(),
    values: lib.z.array(lib.z.object({
        label: lib.z.string(),
        hexColors: lib.z.array(lib.z.string()).optional()
    }))
});
const productImageSchema = lib.z.object({
    url: lib.z.string().url().or(lib.z.string().startsWith("/")),
    alt: lib.z.string().optional(),
    width: lib.z.number().optional(),
    height: lib.z.number().optional()
});
const productVariantSchema = lib.z.object({
    id: lib.z.string(),
    sku: lib.z.string().nullish(),
    name: lib.z.string().optional(),
    options: lib.z.array(productOptionSchema),
    image: productImageSchema.optional()
});
const productSchema = lib.z.object({
    id: lib.z.string(),
    name: lib.z.string(),
    description: lib.z.string(),
    descriptionHtml: lib.z.string().optional(),
    sku: lib.z.string().nullish(),
    slug: lib.z.string(),
    path: lib.z.string().startsWith("/"),
    images: lib.z.array(productImageSchema),
    variants: lib.z.array(productVariantSchema),
    price: productPriceSchema,
    options: lib.z.array(productOptionSchema),
    vendor: lib.z.string().optional()
});
const productsPathsSchema = lib.z.array(lib.z.object({
    path: lib.z.string().startsWith("/")
}));
const searchProductBodySchema = lib.z.object({
    search: lib.z.string().optional(),
    categoryId: lib.z.string().optional(),
    brandId: lib.z.string().optional(),
    sort: lib.z.string().optional(),
    locale: lib.z.string().optional()
});
const searchProductsSchema = lib.z.object({
    products: lib.z.array(productSchema),
    found: lib.z.boolean()
});

;// CONCATENATED MODULE: ../packages/commerce/dist/api/utils/with-operation-callback.js





const withOperationCallback = (name, fn)=>async (...args)=>{
        try {
            const data = await fn(...args);
            parse({
                name,
                data
            });
            return data;
        } catch (error) {
            throw getOperationError(name, error);
        }
    };
const parse = ({ name , data  })=>{
    switch(name){
        case "getProduct":
            productSchema.optional().parse(data.product);
            break;
        case "getAllProducts":
            lib.z.array(productSchema).parse(data.products);
            break;
        case "getAllProductPaths":
            productsPathsSchema.parse(data.products);
            break;
        case "getPage":
            pageSchema.nullable().parse(data.page);
            break;
        case "getAllPages":
            lib.z.array(pageSchema).parse(data.pages);
            break;
        case "getSiteInfo":
            siteInfoSchema.parse(data);
            break;
    }
};

;// CONCATENATED MODULE: ../packages/commerce/dist/api/operations.js
const noop = ()=>{
    throw new Error("Not implemented");
};
const OPERATIONS = [
    "login",
    "getAllPages",
    "getPage",
    "getSiteInfo",
    "getCustomerWishlist",
    "getAllProductPaths",
    "getAllProducts",
    "getProduct", 
];
const defaultOperations = OPERATIONS.reduce((ops, k)=>{
    ops[k] = noop;
    return ops;
}, {});

;// CONCATENATED MODULE: ../packages/commerce/dist/api/index.js


class CommerceAPICore {
    constructor(provider){
        this.provider = provider;
    }
    getConfig(userConfig = {}) {
        return Object.entries(userConfig).reduce((cfg, [key, value])=>Object.assign(cfg, {
                [key]: value
            }), {
            ...this.provider.config
        });
    }
    setConfig(newConfig) {
        Object.assign(this.provider.config, newConfig);
    }
}
function getCommerceApi(customProvider) {
    const commerce = Object.assign(new CommerceAPICore(customProvider), defaultOperations);
    const ops = customProvider.operations;
    OPERATIONS.forEach((k)=>{
        const op = ops[k];
        if (op) {
            commerce[k] = withOperationCallback(k, op({
                commerce
            }));
        }
    });
    return commerce;
}
function getEndpoint(commerce, context) {
    const cfg = commerce.getConfig(context.config);
    return function apiHandler(req) {
        return context.handler({
            req,
            commerce,
            config: cfg,
            handlers: context.handlers,
            options: context.options ?? {}
        });
    };
}
const createEndpoint = (endpoint)=>(commerce, context)=>{
        return getEndpoint(commerce, {
            ...endpoint,
            ...context
        });
    };

;// CONCATENATED MODULE: ../packages/local/dist/api/utils/fetch-local.js

const fetchGraphqlApi = (getConfig)=>async (query, { variables , preview  } = {}, headers)=>{
        const config = getConfig();
        const res = await fetch(config.commerceUrl, {
            method: "POST",
            headers: {
                ...headers,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                query,
                variables
            })
        });
        const json = await res.json();
        if (json.errors) {
            throw new FetcherError({
                errors: json.errors ?? [
                    {
                        message: "Failed to fetch for API"
                    }
                ],
                status: res.status
            });
        }
        return {
            data: json.data,
            res
        };
    };
/* harmony default export */ const fetch_local = (fetchGraphqlApi);

;// CONCATENATED MODULE: ../packages/local/dist/api/operations/get-all-pages.js
function getAllPagesOperation() {
    function getAllPages({ config , preview  }) {
        return Promise.resolve({
            pages: []
        });
    }
    return getAllPages;
};

;// CONCATENATED MODULE: ../packages/local/dist/api/operations/get-page.js
function getPageOperation() {
    function getPage() {
        return Promise.resolve({});
    }
    return getPage;
};

;// CONCATENATED MODULE: ../packages/local/dist/api/operations/get-site-info.js
function getSiteInfoOperation({}) {
    function getSiteInfo({ query , variables , config: cfg  } = {}) {
        return Promise.resolve({
            categories: [
                {
                    id: "new-arrivals",
                    name: "New Arrivals",
                    slug: "new-arrivals",
                    path: "/new-arrivals"
                },
                {
                    id: "featured",
                    name: "Featured",
                    slug: "featured",
                    path: "/featured"
                }, 
            ],
            brands: []
        });
    }
    return getSiteInfo;
};

;// CONCATENATED MODULE: ../packages/local/dist/api/operations/get-customer-wishlist.js
function getCustomerWishlistOperation() {
    function getCustomerWishlist() {
        return {
            wishlist: {}
        };
    }
    return getCustomerWishlist;
};

;// CONCATENATED MODULE: ../packages/local/dist/data.json
const data_namespaceObject = JSON.parse('{"R":[{"id":"Z2lkOi8vc2hvcGlmeS9Qcm9kdWN0LzU0NDczMjUwMjQ0MjA=","name":"New Short Sleeve T-Shirt","vendor":"Next.js","path":"/new-short-sleeve-t-shirt","slug":"new-short-sleeve-t-shirt","price":{"value":25,"currencyCode":"USD"},"description":"Show off your love for Next.js and Vercel with this unique, limited edition t-shirt. This design is part of a limited run, numbered drop at the June 2021 Next.js Conf. It features a unique, handcrafted triangle design. Get it while supplies last - only 200 of these shirts will be made! All proceeds will be donated to charity.","descriptionHtml":"<p><span>Show off your love for Next.js and Vercel with this unique,&nbsp;</span><strong>limited edition</strong><span>&nbsp;t-shirt. This design is part of a limited run, numbered drop at the June 2021 Next.js Conf. It features a unique, handcrafted triangle design. Get it while supplies last - only 200 of these shirts will be made!&nbsp;</span><strong>All proceeds will be donated to charity.</strong></p>","images":[{"url":"/assets/drop-shirt-0.png","altText":"Shirt","width":1000,"height":1000},{"url":"/assets/drop-shirt-1.png","altText":"Shirt","width":1000,"height":1000},{"url":"/assets/drop-shirt-2.png","altText":"Shirt","width":1000,"height":1000}],"variants":[{"id":"Z2lkOi8vc2hvcGlmeS9Qcm9kdWN0LzU0NDczMjUwMjQ0MjAss=","name":"New Short Sleeve T-Shirt","sku":"new-short-sleeve-t-shirt","options":[{"__typename":"MultipleChoiceOption","id":"asd","displayName":"Size","values":[{"label":"XL"}]}]}],"options":[{"id":"option-color","displayName":"Color","values":[{"label":"color","hexColors":["#222"]}]},{"id":"option-size","displayName":"Size","values":[{"label":"S"},{"label":"M"},{"label":"L"}]}]},{"id":"Z2lkOi8vc2hvcGlmeS9Qcm9ksdWN0LzU0NDczMjUwMjQ0MjA=","name":"Lightweight Jacket","vendor":"Next.js","path":"/lightweight-jacket","slug":"lightweight-jacket","price":{"value":249.99,"currencyCode":"USD"},"description":"Show off your love for Next.js and Vercel with this unique, limited edition t-shirt. This design is part of a limited run, numbered drop at the June 2021 Next.js Conf. It features a unique, handcrafted triangle design. Get it while supplies last - only 200 of these shirts will be made! All proceeds will be donated to charity.","descriptionHtml":"<p><span>Show off your love for Next.js and Vercel with this unique,&nbsp;</span><strong>limited edition</strong><span>&nbsp;t-shirt. This design is part of a limited run, numbered drop at the June 2021 Next.js Conf. It features a unique, handcrafted triangle design. Get it while supplies last – only 200 of these shirts will be made!&nbsp;</span><strong>All proceeds will be donated to charity.</strong></p>","images":[{"url":"/assets/lightweight-jacket-0.png","altText":"Lightweight Jacket","width":1000,"height":1000},{"url":"/assets/lightweight-jacket-1.png","altText":"Lightweight Jacket","width":1000,"height":1000},{"url":"/assets/lightweight-jacket-2.png","altText":"Lightweight Jacket","width":1000,"height":1000}],"variants":[{"id":"Z2lkOid8vc2hvcGlmeS9Qcm9kdWN0LzU0NDczMjUwMjQ0MjAss=","name":"Lightweight Jacket","sku":"lightweight-jacket","options":[{"__typename":"MultipleChoiceOption","id":"asd","displayName":"Size","values":[{"label":"XL"}]}]}],"options":[{"id":"option-color","displayName":"Color","values":[{"label":"color","hexColors":["#222"]}]},{"id":"option-size","displayName":"Size","values":[{"label":"S"},{"label":"M"},{"label":"L"}]}]},{"id":"Z2lkOis8vc2hvcGlmsddeS9Qcm9kdWN0LzU0NDczMjUwMjQ0MjA=","name":"Shirt","vendor":"Next.js","path":"/shirt","slug":"shirt","price":{"value":25,"currencyCode":"USD"},"description":"Show off your love for Next.js and Vercel with this unique, limited edition t-shirt. This design is part of a limited run, numbered drop at the June 2021 Next.js Conf. It features a unique, handcrafted triangle design. Get it while supplies last - only 200 of these shirts will be made! All proceeds will be donated to charity.","descriptionHtml":"<p><span>Show off your love for Next.js and Vercel with this unique,&nbsp;</span><strong>limited edition</strong><span>&nbsp;t-shirt. This design is part of a limited run, numbered drop at the June 2021 Next.js Conf. It features a unique, handcrafted triangle design. Get it while supplies last – only 200 of these shirts will be made!&nbsp;</span><strong>All proceeds will be donated to charity.</strong></p>","images":[{"url":"/assets/t-shirt-0.png","altText":"Shirt","width":1000,"height":1000},{"url":"/assets/t-shirt-1.png","altText":"Shirt","width":1000,"height":1000},{"url":"/assets/t-shirt-2.png","altText":"Shirt","width":1000,"height":1000},{"url":"/assets/t-shirt-3.png","altText":"Shirt","width":1000,"height":1000},{"url":"/assets/t-shirt-4.png","altText":"Shirt","width":1000,"height":1000}],"variants":[{"id":"Z2lkOi8vc2hvcGlmeS9Qcms9kdWN0LzU0NDczMjUwMjQ0MjAss=","name":"Shirt","sku":"shirt","options":[{"__typename":"MultipleChoiceOption","id":"asd","displayName":"Size","values":[{"label":"XL"}]}]}],"options":[{"id":"option-color","displayName":"Color","values":[{"label":"color","hexColors":["#222"]}]},{"id":"option-size","displayName":"Size","values":[{"label":"S"},{"label":"M"},{"label":"L"}]}]}]}');
;// CONCATENATED MODULE: ../packages/local/dist/api/operations/get-all-product-paths.js

function getAllProductPathsOperation() {
    function getAllProductPaths() {
        return Promise.resolve({
            products: data_namespaceObject.R.map(({ path  })=>({
                    path
                }))
        });
    }
    return getAllProductPaths;
};

;// CONCATENATED MODULE: ../packages/local/dist/api/operations/get-all-products.js

function getAllProductsOperation({ commerce  }) {
    async function getAllProducts({ query ="" , variables , config  } = {}) {
        return {
            products: data_namespaceObject.R
        };
    }
    return getAllProducts;
};

;// CONCATENATED MODULE: ../packages/local/dist/api/operations/get-product.js

function getProductOperation(_p) {
    async function getProduct({ query ="" , variables , config  } = {}) {
        return {
            product: data_namespaceObject.R.find(({ slug  })=>slug === variables.slug)
        };
    }
    return getProduct;
};

;// CONCATENATED MODULE: ../packages/local/dist/api/index.js









const config = {
    commerceUrl: "",
    apiToken: "",
    cartCookie: "",
    customerCookie: "",
    cartCookieMaxAge: 2592000,
    fetch: fetch_local(()=>api_getCommerceApi().getConfig())
};
const operations = {
    getAllPages: getAllPagesOperation,
    getPage: getPageOperation,
    getSiteInfo: getSiteInfoOperation,
    getCustomerWishlist: getCustomerWishlistOperation,
    getAllProductPaths: getAllProductPathsOperation,
    getAllProducts: getAllProductsOperation,
    getProduct: getProductOperation
};
const provider = {
    config,
    operations
};
function api_getCommerceApi(customProvider = provider) {
    return getCommerceApi(customProvider);
}

;// CONCATENATED MODULE: ./lib/api/commerce.ts

/* harmony default export */ const commerce = (api_getCommerceApi());

;// CONCATENATED MODULE: external "next/server"
const server_namespaceObject = require("next/server");
;// CONCATENATED MODULE: ../packages/commerce/dist/api/utils/index.js

/**
 * Parses the output data of the API handler and returns a valid APIResponse
 * or throws an error if the data is invalid.
 * @param res  APIResponse
 * @param parser ZodSchema
 */ const utils_parse = (res, parser)=>{
    if (res.data) {
        res.data = parser.parse(res.data);
    }
    return res;
};
/**
 * Returns the body of the request as a JSON object.
 * @param req NextRequest
 */ const getInput = (req)=>req.json().catch(()=>({}));
/**
 * Convert NextApiRequest to NextRequest
 * @param req NextApiRequest
 * @param path string
 */ const transformRequest = (req, path)=>{
    const headers = new Headers();
    let body;
    for(let i = 0; i < req.rawHeaders.length; i += 2){
        headers.append(req.rawHeaders[i], req.rawHeaders[i + 1]);
    }
    if (req.method === "POST" || req.method === "PUT" || req.method === "DELETE") {
        body = JSON.stringify(req.body);
    }
    return new server_namespaceObject.NextRequest(`https://${req.headers.host}/api/commerce/${path}`, {
        headers,
        method: req.method,
        body
    });
};
/**
 * Sets the custom headers received in the APIResponse in the
 * @param headers Record<string, string|string[]> | Headers | undefined
 * @returns Headers
 */ const transformHeaders = (headers = {})=>{
    if (headers instanceof Headers) {
        return headers;
    }
    const newHeaders = new Headers();
    Object.entries(headers).forEach(([key, value])=>{
        newHeaders.append(key, value);
    });
    return newHeaders;
};
const setHeaders = (res, headers = {})=>{
    if (headers instanceof Headers) {
        headers.forEach((value, key)=>{
            res.setHeader(key, value);
        });
    } else {
        Object.entries(headers).forEach(([key, value])=>{
            res.setHeader(key, value);
        });
    }
};

;// CONCATENATED MODULE: ../packages/commerce/dist/api/utils/node-handler.js


function nodeHandler(commerce, endpoints) {
    const paths = Object.keys(endpoints);
    const handlers = paths.reduce((acc, path)=>Object.assign(acc, {
            [path]: endpoints[path](commerce)
        }), {});
    return async (req, res)=>{
        try {
            if (!req.query.commerce) {
                throw new Error("Invalid configuration. Please make sure that the /pages/api/commerce/[[...commerce]].ts route is configured correctly, and it passes the commerce instance.");
            }
            /**
       * Get the url path
       */ const path = Array.isArray(req.query.commerce) ? req.query.commerce.join("/") : req.query.commerce;
            // Check if the handler for this path exists and return a 404 if it doesn't
            if (!paths.includes(path)) {
                throw new Error(`Endpoint handler not implemented. Please use one of the available api endpoints: ${paths.join(", ")}`);
            }
            const output = await handlers[path](transformRequest(req, path));
            const { status , errors , data , redirectTo , headers  } = output;
            setHeaders(res, headers);
            if (output instanceof Response) {
                return res.end(output.body);
            }
            if (redirectTo) {
                return res.redirect(redirectTo);
            }
            res.status(status || 200).json({
                data,
                errors
            });
        } catch (error) {
            const output1 = normalizeApiError(error);
            if (output1 instanceof Response) {
                return res.end(output1.body);
            }
            const { status: status1 = 500 , ...rest } = output1;
            res.status(status1).json(rest);
        }
    };
};

;// CONCATENATED MODULE: ../packages/commerce/dist/api/endpoints/index.js


/**
 * Next.js Commerce API endpoints handler. Based on the path, it will call the corresponding endpoint handler,
 * exported from the `endpoints` folder of the provider.
 * @param {CommerceAPI} commerce The Commerce API instance.
 * @param endpoints An object containing the handlers for each endpoint.
 */ /* harmony default export */ const endpoints = ( false ? 0 : nodeHandler);

;// CONCATENATED MODULE: ../packages/local/dist/api/endpoints.js

const endpoints_endpoints = {};
function localAPI(commerce) {
    return endpoints(commerce, endpoints_endpoints);
};

;// CONCATENATED MODULE: ./pages/api/commerce/[[...commerce]].ts


// export const config = {
//   runtime: 'experimental-edge',
// }
/* harmony default export */ const _commerce_ = (localAPI(commerce));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [877], () => (__webpack_exec__(5850)));
module.exports = __webpack_exports__;

})();