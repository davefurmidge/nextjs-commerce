exports.id = 450;
exports.ids = [450];
exports.modules = {

/***/ 9674:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "CartItem_root__n8ra_",
	"quantity": "CartItem_quantity__qmi6Q",
	"productImage": "CartItem_productImage__VapbI",
	"productName": "CartItem_productName__RYrlX"
};


/***/ }),

/***/ 4338:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "CartSidebarView_root__5gpRe",
	"empty": "CartSidebarView_empty__fvfi0",
	"lineItemsList": "CartSidebarView_lineItemsList__StJOa"
};


/***/ }),

/***/ 4000:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "CheckoutSidebarView_root__hj993",
	"lineItemsList": "CheckoutSidebarView_lineItemsList__zjdUk"
};


/***/ }),

/***/ 9040:
/***/ ((module) => {

// Exports
module.exports = {
	"fieldset": "PaymentMethodView_fieldset__QEB59",
	"label": "PaymentMethodView_label__xM6ed",
	"input": "PaymentMethodView_input__vj9M1",
	"select": "PaymentMethodView_select__32jl5"
};


/***/ }),

/***/ 9210:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "PaymentWidget_root__Y8ogL"
};


/***/ }),

/***/ 324:
/***/ ((module) => {

// Exports
module.exports = {
	"fieldset": "ShippingView_fieldset__h5IA5",
	"label": "ShippingView_label__Mempp",
	"input": "ShippingView_input__lslSw",
	"select": "ShippingView_select__n5mpB",
	"radio": "ShippingView_radio__MFeU4"
};


/***/ }),

/***/ 9881:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "ShippingWidget_root__b3tUJ"
};


/***/ }),

/***/ 6880:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Footer_root__r3DO1",
	"link": "Footer_link__gh2xK"
};


/***/ }),

/***/ 3269:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "I18nWidget_root__8oEqG",
	"button": "I18nWidget_button__uym6x",
	"dropdownMenu": "I18nWidget_dropdownMenu__gtqFq",
	"item": "I18nWidget_item__1UqGL",
	"icon": "I18nWidget_icon__CyjQG",
	"active": "I18nWidget_active__JLYZI",
	"closeButton": "I18nWidget_closeButton__X96JH"
};


/***/ }),

/***/ 3583:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Layout_root___g0be"
};


/***/ }),

/***/ 9786:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Navbar_root__oKPSU",
	"nav": "Navbar_nav__FsbqY",
	"navMenu": "Navbar_navMenu__lJ9fT",
	"link": "Navbar_link__Z6GsF",
	"logo": "Navbar_logo__grQMD"
};


/***/ }),

/***/ 1628:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Searchbar_root__i4oSJ",
	"input": "Searchbar_input__NfaB1",
	"iconContainer": "Searchbar_iconContainer__1Tln2",
	"icon": "Searchbar_icon__fajpH"
};


/***/ }),

/***/ 4228:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "SidebarLayout_root__d94Sj",
	"header": "SidebarLayout_header__szwlA",
	"container": "SidebarLayout_container__hqrjW"
};


/***/ }),

/***/ 5418:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "CustomerMenuContent_root__k94mX",
	"link": "CustomerMenuContent_link__vMGNV",
	"active": "CustomerMenuContent_active__qzD1a"
};


/***/ }),

/***/ 1112:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "MenuSidebarView_root__QjWQB",
	"item": "MenuSidebarView_item__Y2hvw"
};


/***/ }),

/***/ 3317:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "UserNav_root__7GZb3",
	"list": "UserNav_list__a5C3J",
	"item": "UserNav_item__Tv14Y",
	"bagCount": "UserNav_bagCount__D9pjg",
	"avatarButton": "UserNav_avatarButton__9exMf",
	"mobileMenu": "UserNav_mobileMenu__De3Ei",
	"dropdownDesktop": "UserNav_dropdownDesktop__mL6k4",
	"dropdownMobile": "UserNav_dropdownMobile__mNeEo"
};


/***/ }),

/***/ 5273:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Button_root__G_l9X",
	"loading": "Button_loading__4K_aO",
	"slim": "Button_slim__WmpZF",
	"ghost": "Button_ghost__zWAsk",
	"naked": "Button_naked__xwcQp",
	"disabled": "Button_disabled__Ksgjy",
	"progress": "Button_progress__X8l1J"
};


/***/ }),

/***/ 7707:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Dropdown_root__MUh9b",
	"slideIn": "Dropdown_slideIn__O6w89"
};


/***/ }),

/***/ 5621:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Input_root__eG6Wl"
};


/***/ }),

/***/ 1852:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "LoadingDots_root__L3YhM",
	"dot": "LoadingDots_dot__YIHAP",
	"blink": "LoadingDots_blink__8sST9"
};


/***/ }),

/***/ 6769:
/***/ ((module) => {

// Exports
module.exports = {
	"actions": "Quantity_actions__C9fVt",
	"input": "Quantity_input__yBzs3"
};


/***/ }),

/***/ 8718:
/***/ ((module) => {

// Exports
module.exports = {
	"root": "Sidebar_root__hUV6J",
	"sidebar": "Sidebar_sidebar__7UX4L",
	"backdrop": "Sidebar_backdrop__uAThX"
};


/***/ }),

/***/ 9054:
/***/ ((module) => {

// Exports
module.exports = {
	"body": "Text_body__ldD0k",
	"heading": "Text_heading__jNwbK",
	"pageHeading": "Text_pageHeading__VhZNf",
	"sectionHeading": "Text_sectionHeading__cIo0_"
};


/***/ }),

/***/ 3368:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4393);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5736);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2261);
/* harmony import */ var _framework_auth_use_login__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2428);
/* harmony import */ var _components_ui_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5409);
/* harmony import */ var email_validator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1072);
/* harmony import */ var email_validator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(email_validator__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui__WEBPACK_IMPORTED_MODULE_7__]);
_components_ui__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const LoginView = ()=>{
    // Form State
    const [email, setEmail] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [password, setPassword] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [message, setMessage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [dirty, setDirty] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [disabled, setDisabled] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { setModalView , closeModal  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_3__/* .useUI */ .l8)();
    const login = (0,_framework_auth_use_login__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const handleLogin = async (e)=>{
        e.preventDefault();
        if (!dirty && !disabled) {
            setDirty(true);
            handleValidation();
        }
        try {
            setLoading(true);
            setMessage("");
            await login({
                email,
                password
            });
            setLoading(false);
            closeModal();
        } catch ({ errors  }) {
            if (errors instanceof Array) {
                setMessage(errors.map((e)=>e.message).join("<br/>"));
            } else {
                setMessage("Unexpected error");
            }
            setLoading(false);
            setDisabled(false);
        }
    };
    const handleValidation = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        // Test for Alphanumeric password
        const validPassword = /^(?=.*[a-zA-Z])(?=.*[0-9])/.test(password);
        // Unable to send form unless fields are valid.
        if (dirty) {
            setDisabled(!(0,email_validator__WEBPACK_IMPORTED_MODULE_2__.validate)(email) || password.length < 7 || !validPassword);
        }
    }, [
        email,
        password,
        dirty
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        handleValidation();
    }, [
        handleValidation
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
        onSubmit: handleLogin,
        className: "w-80 flex flex-col justify-between p-3",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex justify-center pb-12 ",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    width: "64px",
                    height: "64px"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col space-y-3",
                children: [
                    message && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "text-red border border-red p-3",
                        children: [
                            message,
                            ". Did you ",
                            ` `,
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                className: "text-accent-9 inline font-bold hover:underline cursor-pointer",
                                onClick: ()=>setModalView("FORGOT_VIEW"),
                                children: "forgot your password?"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        type: "email",
                        placeholder: "Email",
                        onChange: setEmail
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        type: "password",
                        placeholder: "Password",
                        onChange: setPassword
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        variant: "slim",
                        type: "submit",
                        loading: loading,
                        disabled: disabled,
                        children: "Log In"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "pt-1 text-center text-sm",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-accent-7",
                                children: "Don't have an account?"
                            }),
                            ` `,
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                className: "text-accent-9 font-bold hover:underline cursor-pointer",
                                onClick: ()=>setModalView("SIGNUP_VIEW"),
                                children: "Sign Up"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LoginView);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8848:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ CartItem_CartItem)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "clsx"
var external_clsx_ = __webpack_require__(8103);
var external_clsx_default = /*#__PURE__*/__webpack_require__.n(external_clsx_);
// EXTERNAL MODULE: ../node_modules/.pnpm/next@13.0.4_biqbaboplfbrettd7655fr4n2y/node_modules/next/image.js
var next_image = __webpack_require__(3558);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ../node_modules/.pnpm/next@13.0.4_biqbaboplfbrettd7655fr4n2y/node_modules/next/link.js
var next_link = __webpack_require__(1958);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/cart/CartItem/CartItem.module.css
var CartItem_module = __webpack_require__(9674);
var CartItem_module_default = /*#__PURE__*/__webpack_require__.n(CartItem_module);
// EXTERNAL MODULE: ./components/ui/context.tsx
var context = __webpack_require__(5409);
// EXTERNAL MODULE: ../packages/commerce/dist/product/use-price.js
var use_price = __webpack_require__(4398);
// EXTERNAL MODULE: ../packages/local/dist/cart/use-update-item.js + 1 modules
var use_update_item = __webpack_require__(6789);
// EXTERNAL MODULE: ../packages/local/dist/cart/use-remove-item.js + 1 modules
var use_remove_item = __webpack_require__(7260);
// EXTERNAL MODULE: ./components/ui/Quantity/Quantity.module.css
var Quantity_module = __webpack_require__(6769);
var Quantity_module_default = /*#__PURE__*/__webpack_require__.n(Quantity_module);
// EXTERNAL MODULE: ./components/icons/Cross.tsx
var Cross = __webpack_require__(1609);
;// CONCATENATED MODULE: ./components/icons/Minus.tsx

const Minus = ({ ...props })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        ...props,
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M5 12H19",
            stroke: "currentColor",
            strokeWidth: "1.5",
            strokeLinecap: "round",
            strokeLinejoin: "round"
        })
    });
};
/* harmony default export */ const icons_Minus = (Minus);

;// CONCATENATED MODULE: ./components/icons/Plus.tsx

const Plus = ({ ...props })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M12 5V19",
                stroke: "currentColor",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                d: "M5 12H19",
                stroke: "currentColor",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            })
        ]
    });
};
/* harmony default export */ const icons_Plus = (Plus);

;// CONCATENATED MODULE: ./components/ui/Quantity/Quantity.tsx





const Quantity = ({ value , increase , decrease , handleChange , handleRemove , max =6  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-row h-9",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                className: (Quantity_module_default()).actions,
                onClick: handleRemove,
                children: /*#__PURE__*/ jsx_runtime_.jsx(Cross/* default */.Z, {
                    width: 20,
                    height: 20
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("label", {
                className: "w-full border-accent-2 border ml-2",
                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                    className: (Quantity_module_default()).input,
                    onChange: (e)=>Number(e.target.value) < max + 1 ? handleChange(e) : ()=>{},
                    value: value,
                    type: "number",
                    max: max,
                    min: "0",
                    readOnly: true
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                type: "button",
                onClick: decrease,
                className: (Quantity_module_default()).actions,
                style: {
                    marginLeft: "-1px"
                },
                disabled: value <= 1,
                children: /*#__PURE__*/ jsx_runtime_.jsx(icons_Minus, {
                    width: 18,
                    height: 18
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                type: "button",
                onClick: increase,
                className: external_clsx_default()((Quantity_module_default()).actions),
                style: {
                    marginLeft: "-1px"
                },
                disabled: value < 1 || value >= max,
                children: /*#__PURE__*/ jsx_runtime_.jsx(icons_Plus, {
                    width: 18,
                    height: 18
                })
            })
        ]
    });
};
/* harmony default export */ const Quantity_Quantity = (Quantity);

;// CONCATENATED MODULE: ./components/cart/CartItem/CartItem.tsx











const placeholderImg = "/product-img-placeholder.svg";
const CartItem = ({ item , variant ="default" , currencyCode , ...rest })=>{
    const { closeSidebarIfPresent  } = (0,context/* useUI */.l8)();
    const [removing, setRemoving] = (0,external_react_.useState)(false);
    const [quantity, setQuantity] = (0,external_react_.useState)(item.quantity);
    const removeItem = (0,use_remove_item/* default */.Z)();
    const updateItem = (0,use_update_item/* default */.Z)({
        item
    });
    const { price  } = (0,use_price/* default */.ZP)({
        amount: item.variant.price * item.quantity,
        baseAmount: item.variant.listPrice * item.quantity,
        currencyCode
    });
    const handleChange = async ({ target: { value  }  })=>{
        setQuantity(Number(value));
        await updateItem({
            quantity: Number(value)
        });
    };
    const increaseQuantity = async (n = 1)=>{
        const val = Number(quantity) + n;
        setQuantity(val);
        await updateItem({
            quantity: val
        });
    };
    const handleRemove = async ()=>{
        setRemoving(true);
        try {
            await removeItem(item);
        } catch (error) {
            setRemoving(false);
        }
    };
    // TODO: Add a type for this
    const options = item.options;
    (0,external_react_.useEffect)(()=>{
        // Reset the quantity state if the item quantity changes
        if (item.quantity !== Number(quantity)) {
            setQuantity(item.quantity);
        }
    // TODO: currently not including quantity in deps is intended, but we should
    // do this differently as it could break easily
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        item.quantity
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
        className: external_clsx_default()((CartItem_module_default()).root, {
            "opacity-50 pointer-events-none": removing
        }),
        ...rest,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-row space-x-4 py-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-16 h-16 bg-violet relative overflow-hidden cursor-pointer",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: `/product/${item.path}`,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                onClick: ()=>closeSidebarIfPresent(),
                                className: (CartItem_module_default()).productImage,
                                width: 64,
                                height: 64,
                                src: item.variant.image?.url || placeholderImg,
                                alt: item.variant.image?.alt || "Product Image"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex-1 flex flex-col text-base",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: `/product/${item.path}`,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: (CartItem_module_default()).productName,
                                    onClick: ()=>closeSidebarIfPresent(),
                                    children: item.name
                                })
                            }),
                            options && options.length > 0 && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex items-center pb-1",
                                children: options.map((option, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "text-sm font-semibold text-accent-7 inline-flex items-center justify-center",
                                        children: [
                                            option.name,
                                            option.name === "Color" ? /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "mx-2 rounded-full bg-transparent border w-5 h-5 p-1 text-accent-9 inline-flex items-center justify-center overflow-hidden",
                                                style: {
                                                    backgroundColor: `${option.value}`
                                                }
                                            }) : /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "mx-2 rounded-full bg-transparent border h-5 p-1 text-accent-9 inline-flex items-center justify-center overflow-hidden",
                                                children: option.value
                                            }),
                                            i === options.length - 1 ? "" : /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "mr-3"
                                            })
                                        ]
                                    }, `${item.id}-${option.name}`))
                            }),
                            variant === "display" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "text-sm tracking-wider",
                                children: [
                                    quantity,
                                    "x"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "flex flex-col justify-between space-y-2 text-sm",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: price
                        })
                    })
                ]
            }),
            variant === "default" && /*#__PURE__*/ jsx_runtime_.jsx(Quantity_Quantity, {
                value: quantity,
                handleRemove: handleRemove,
                handleChange: handleChange,
                increase: ()=>increaseQuantity(1),
                decrease: ()=>increaseQuantity(-1)
            })
        ]
    });
};
/* harmony default export */ const CartItem_CartItem = (CartItem);


/***/ }),

/***/ 8457:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1958);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _CartSidebarView_module_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4338);
/* harmony import */ var _CartSidebarView_module_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_CartSidebarView_module_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _CartItem__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(8848);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4084);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2261);
/* harmony import */ var _components_ui_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5409);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8663);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1609);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7225);
/* harmony import */ var _framework_cart_use_cart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6973);
/* harmony import */ var _framework_product_use_price__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4398);
/* harmony import */ var _components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6794);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_framework_cart_use_cart__WEBPACK_IMPORTED_MODULE_4__, _components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_6__, _components_ui__WEBPACK_IMPORTED_MODULE_13__]);
([_framework_cart_use_cart__WEBPACK_IMPORTED_MODULE_4__, _components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_6__, _components_ui__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const CartSidebarView = ()=>{
    const { closeSidebar , setSidebarView  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_3__/* .useUI */ .l8)();
    const { data , isLoading , isEmpty  } = (0,_framework_cart_use_cart__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const { price: subTotal  } = (0,_framework_product_use_price__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP)(data && {
        amount: Number(data.subtotalPrice),
        currencyCode: data.currency.code
    });
    const { price: total  } = (0,_framework_product_use_price__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .ZP)(data && {
        amount: Number(data.totalPrice),
        currencyCode: data.currency.code
    });
    const handleClose = ()=>closeSidebar();
    const goToCheckout = ()=>setSidebarView("CHECKOUT_VIEW");
    const error = null;
    const success = null;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        className: clsx__WEBPACK_IMPORTED_MODULE_1___default()({
            [(_CartSidebarView_module_css__WEBPACK_IMPORTED_MODULE_7___default().empty)]: error || success || isLoading || isEmpty
        }),
        handleClose: handleClose,
        children: isLoading || isEmpty ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex-1 px-4 flex flex-col justify-center items-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "border border-dashed border-primary rounded-full flex items-center justify-center w-16 h-16 p-12 bg-secondary text-secondary",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        className: "absolute"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                    className: "pt-6 text-2xl font-bold tracking-wide text-center",
                    children: "Your cart is empty"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "text-accent-3 px-10 text-center pt-2",
                    children: "Biscuit oat cake wafer icing ice cream tiramisu pudding cupcake."
                })
            ]
        }) : error ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex-1 px-4 flex flex-col justify-center items-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "border border-white rounded-full flex items-center justify-center w-16 h-16",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        width: 24,
                        height: 24
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                    className: "pt-6 text-xl font-light text-center",
                    children: "We couldn’t process the purchase. Please check your card information and try again."
                })
            ]
        }) : success ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex-1 px-4 flex flex-col justify-center items-center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "border border-white rounded-full flex items-center justify-center w-16 h-16",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {})
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                    className: "pt-6 text-xl font-light text-center",
                    children: "Thank you for your order."
                })
            ]
        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "px-4 sm:px-6 flex-1",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "/cart",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                variant: "sectionHeading",
                                onClick: handleClose,
                                children: "My Cart"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                            className: (_CartSidebarView_module_css__WEBPACK_IMPORTED_MODULE_7___default().lineItemsList),
                            children: data.lineItems.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CartItem__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                    item: item,
                                    currencyCode: data.currency.code
                                }, item.id))
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex-shrink-0 px-6 py-6 sm:px-6 sticky z-20 bottom-0 w-full right-0 left-0 bg-accent-0 border-t text-sm",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                            className: "pb-2",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    className: "flex justify-between py-1",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: "Subtotal"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: subTotal
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    className: "flex justify-between py-1",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: "Taxes"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: "Calculated at checkout"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    className: "flex justify-between py-1",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: "Shipping"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "font-bold tracking-wide",
                                            children: "FREE"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex justify-between border-t border-accent-2 py-3 font-bold mb-2",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "Total"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: total
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: process.env.COMMERCE_CUSTOMCHECKOUT_ENABLED ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                Component: "a",
                                width: "100%",
                                onClick: goToCheckout,
                                children: [
                                    "Proceed to Checkout (",
                                    total,
                                    ")"
                                ]
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                href: "/checkout",
                                Component: "a",
                                width: "100%",
                                children: "Proceed to Checkout"
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CartSidebarView);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2670:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1958);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_cart_CartItem__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8848);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4084);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2261);
/* harmony import */ var _components_ui_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5409);
/* harmony import */ var _components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6794);
/* harmony import */ var _framework_cart_use_cart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6973);
/* harmony import */ var _framework_product_use_price__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4398);
/* harmony import */ var _framework_checkout_use_checkout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2020);
/* harmony import */ var _ShippingWidget__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1976);
/* harmony import */ var _PaymentWidget__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6557);
/* harmony import */ var _CheckoutSidebarView_module_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4000);
/* harmony import */ var _CheckoutSidebarView_module_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_CheckoutSidebarView_module_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2361);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_framework_cart_use_cart__WEBPACK_IMPORTED_MODULE_4__, _framework_checkout_use_checkout__WEBPACK_IMPORTED_MODULE_5__, _components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_8__, _components_ui__WEBPACK_IMPORTED_MODULE_14__]);
([_framework_cart_use_cart__WEBPACK_IMPORTED_MODULE_4__, _framework_checkout_use_checkout__WEBPACK_IMPORTED_MODULE_5__, _components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_8__, _components_ui__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














const CheckoutSidebarView = ()=>{
    const [loadingSubmit, setLoadingSubmit] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { setSidebarView , closeSidebar  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_3__/* .useUI */ .l8)();
    const { data: cartData , mutate: refreshCart  } = (0,_framework_cart_use_cart__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const { data: checkoutData , submit: onCheckout  } = (0,_framework_checkout_use_checkout__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const { clearCheckoutFields  } = (0,_context__WEBPACK_IMPORTED_MODULE_6__/* .useCheckoutContext */ .w6)();
    async function handleSubmit(event) {
        try {
            setLoadingSubmit(true);
            event.preventDefault();
            await onCheckout();
            clearCheckoutFields();
            setLoadingSubmit(false);
            refreshCart();
            closeSidebar();
        } catch  {
            // TODO - handle error UI here.
            setLoadingSubmit(false);
        }
    }
    const { price: subTotal  } = (0,_framework_product_use_price__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP)(cartData && {
        amount: Number(cartData.subtotalPrice),
        currencyCode: cartData.currency.code
    });
    const { price: total  } = (0,_framework_product_use_price__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP)(cartData && {
        amount: Number(cartData.totalPrice),
        currencyCode: cartData.currency.code
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
        className: (_CheckoutSidebarView_module_css__WEBPACK_IMPORTED_MODULE_9___default().root),
        handleBack: ()=>setSidebarView("CART_VIEW"),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "px-4 sm:px-6 flex-1",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                        href: "/cart",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                            variant: "sectionHeading",
                            children: "Checkout"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PaymentWidget__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                        isValid: checkoutData?.hasPayment,
                        onClick: ()=>setSidebarView("PAYMENT_VIEW")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ShippingWidget__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        isValid: checkoutData?.hasShipping,
                        onClick: ()=>setSidebarView("SHIPPING_VIEW")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: (_CheckoutSidebarView_module_css__WEBPACK_IMPORTED_MODULE_9___default().lineItemsList),
                        children: cartData.lineItems.map((item)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cart_CartItem__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                item: item,
                                currencyCode: cartData.currency.code,
                                variant: "display"
                            }, item.id))
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                onSubmit: handleSubmit,
                className: "flex-shrink-0 px-6 py-6 sm:px-6 sticky z-20 bottom-0 w-full right-0 left-0 bg-accent-0 border-t text-sm",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: "pb-2",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "flex justify-between py-1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Subtotal"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: subTotal
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "flex justify-between py-1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Taxes"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Calculated at checkout"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "flex justify-between py-1",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Shipping"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "font-bold tracking-wide",
                                        children: "FREE"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex justify-between border-t border-accent-2 py-3 font-bold mb-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "Total"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: total
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                            type: "submit",
                            width: "100%",
                            disabled: !checkoutData?.hasPayment || !checkoutData?.hasShipping,
                            loading: loadingSubmit,
                            children: "Confirm Purchase"
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CheckoutSidebarView);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6321:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _framework_customer_card_use_add_item__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7754);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4084);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2261);
/* harmony import */ var _components_ui_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5409);
/* harmony import */ var _components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6794);
/* harmony import */ var _PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9040);
/* harmony import */ var _PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_4__, _components_ui__WEBPACK_IMPORTED_MODULE_7__]);
([_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_4__, _components_ui__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const PaymentMethodView = ()=>{
    const { setSidebarView  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_2__/* .useUI */ .l8)();
    const addCard = (0,_framework_customer_card_use_add_item__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    async function handleSubmit(event) {
        event.preventDefault();
        await addCard({
            cardHolder: event.target.cardHolder.value,
            cardNumber: event.target.cardNumber.value,
            cardExpireDate: event.target.cardExpireDate.value,
            cardCvc: event.target.cardCvc.value,
            firstName: event.target.firstName.value,
            lastName: event.target.lastName.value,
            company: event.target.company.value,
            streetNumber: event.target.streetNumber.value,
            zipCode: event.target.zipCode.value,
            city: event.target.city.value,
            country: event.target.country.value
        });
        setSidebarView("CHECKOUT_VIEW");
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
        className: "h-full",
        onSubmit: handleSubmit,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            handleBack: ()=>setSidebarView("CHECKOUT_VIEW"),
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "px-4 sm:px-6 flex-1",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            variant: "sectionHeading",
                            children: " Payment Method"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                            children: "Cardholder Name"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            name: "cardHolder",
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "grid gap-3 grid-flow-row grid-cols-12",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset), "col-span-7"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                                    children: "Card Number"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "cardNumber",
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset), "col-span-3"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                                    children: "Expires"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "cardExpireDate",
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input),
                                                    placeholder: "MM/YY"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset), "col-span-2"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                                    children: "CVC"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "cardCvc",
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input)
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                    className: "border-accent-2 my-6"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "grid gap-3 grid-flow-row grid-cols-12",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset), "col-span-6"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                                    children: "First Name"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "firstName",
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset), "col-span-6"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                                    children: "Last Name"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "lastName",
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input)
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                            children: "Company (Optional)"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            name: "company",
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                            children: "Street and House Number"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            name: "streetNumber",
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                            children: "Apartment, Suite, Etc. (Optional)"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input),
                                            name: "apartment"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "grid gap-3 grid-flow-row grid-cols-12",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset), "col-span-6"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                                    children: "Postal Code"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "zipCode",
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset), "col-span-6"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                                    children: "City"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "city",
                                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().input)
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().fieldset),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().label),
                                            children: "Country/Region"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                            name: "country",
                                            className: (_PaymentMethodView_module_css__WEBPACK_IMPORTED_MODULE_6___default().select),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                children: "Hong Kong"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "sticky z-20 bottom-0 w-full right-0 left-0 py-12 bg-accent-0 border-t border-accent-2 px-6",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                        type: "submit",
                        width: "100%",
                        variant: "ghost",
                        children: "Continue"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PaymentMethodView);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6557:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _PaymentWidget_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9210);
/* harmony import */ var _PaymentWidget_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_PaymentWidget_module_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4259);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7225);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6940);



const PaymentWidget = ({ onClick , isValid  })=>{
    /* Shipping Address
  Only available with checkout set to true -
  This means that the provider does offer checkout functionality. */ return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        onClick: onClick,
        className: (_PaymentWidget_module_css__WEBPACK_IMPORTED_MODULE_1___default().root),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-1 items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        className: "w-5 flex"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "ml-5 text-sm text-center font-medium",
                        children: "Add Payment Method"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: isValid ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PaymentWidget);


/***/ }),

/***/ 1966:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_ui_Button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2261);
/* harmony import */ var _components_ui_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5409);
/* harmony import */ var _components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6794);
/* harmony import */ var _framework_customer_address_use_add_item__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8056);
/* harmony import */ var _ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(324);
/* harmony import */ var _ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_4__, _components_ui_Button__WEBPACK_IMPORTED_MODULE_6__]);
([_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_4__, _components_ui_Button__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const ShippingView = ()=>{
    const { setSidebarView  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_2__/* .useUI */ .l8)();
    const addAddress = (0,_framework_customer_address_use_add_item__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z)();
    async function handleSubmit(event) {
        event.preventDefault();
        await addAddress({
            type: event.target.type.value,
            firstName: event.target.firstName.value,
            lastName: event.target.lastName.value,
            company: event.target.company.value,
            streetNumber: event.target.streetNumber.value,
            apartments: event.target.streetNumber.value,
            zipCode: event.target.zipCode.value,
            city: event.target.city.value,
            country: event.target.country.value
        });
        setSidebarView("CHECKOUT_VIEW");
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
        className: "h-full",
        onSubmit: handleSubmit,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            handleBack: ()=>setSidebarView("CHECKOUT_VIEW"),
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "px-4 sm:px-6 flex-1",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            className: "pt-1 pb-8 text-2xl font-semibold tracking-wide cursor-pointer inline-block",
                            children: "Shipping"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-row my-3 items-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            name: "type",
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().radio),
                                            type: "radio"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "ml-3 text-sm",
                                            children: "Same as billing address"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-row my-3 items-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            name: "type",
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().radio),
                                            type: "radio"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            className: "ml-3 text-sm",
                                            children: "Use a different shipping address"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                    className: "border-accent-2 my-6"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "grid gap-3 grid-flow-row grid-cols-12",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().fieldset), "col-span-6"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().label),
                                                    children: "First Name"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "firstName",
                                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().input)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().fieldset), "col-span-6"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().label),
                                                    children: "Last Name"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "lastName",
                                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().input)
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().fieldset),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().label),
                                            children: "Company (Optional)"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            name: "company",
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().input)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().fieldset),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().label),
                                            children: "Street and House Number"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            name: "streetNumber",
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().input)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().fieldset),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().label),
                                            children: "Apartment, Suite, Etc. (Optional)"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            name: "apartments",
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().input)
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "grid gap-3 grid-flow-row grid-cols-12",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().fieldset), "col-span-6"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().label),
                                                    children: "Postal Code"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "zipCode",
                                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().input)
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().fieldset), "col-span-6"),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().label),
                                                    children: "City"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    name: "city",
                                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().input)
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().fieldset),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().label),
                                            children: "Country/Region"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("select", {
                                            name: "country",
                                            className: (_ShippingView_module_css__WEBPACK_IMPORTED_MODULE_5___default().select),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                children: "Hong Kong"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "sticky z-20 bottom-0 w-full right-0 left-0 py-12 bg-accent-0 border-t border-accent-2 px-6",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_Button__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        type: "submit",
                        width: "100%",
                        variant: "ghost",
                        children: "Continue"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ShippingView);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1976:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ShippingWidget_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9881);
/* harmony import */ var _ShippingWidget_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ShippingWidget_module_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7131);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7225);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6940);



const ShippingWidget = ({ onClick , isValid  })=>{
    /* Shipping Address
  Only available with checkout set to true -
  This means that the provider does offer checkout functionality. */ return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        onClick: onClick,
        className: (_ShippingWidget_module_css__WEBPACK_IMPORTED_MODULE_1___default().root),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-1 items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        className: "w-5 flex"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        className: "ml-5 text-sm text-center font-medium",
                        children: "Add Shipping Address"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                children: isValid ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ShippingWidget);


/***/ }),

/***/ 2361:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "oo": () => (/* binding */ CheckoutProvider),
/* harmony export */   "w6": () => (/* binding */ useCheckoutContext)
/* harmony export */ });
/* unused harmony export CheckoutContext */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const initialState = {
    cardFields: {},
    addressFields: {}
};
const CheckoutContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)(initialState);
CheckoutContext.displayName = "CheckoutContext";
const checkoutReducer = (state, action)=>{
    switch(action.type){
        case "SET_CARD_FIELDS":
            return {
                ...state,
                cardFields: action.card
            };
        case "SET_ADDRESS_FIELDS":
            return {
                ...state,
                addressFields: action.address
            };
        case "CLEAR_CHECKOUT_FIELDS":
            return {
                ...state,
                cardFields: initialState.cardFields,
                addressFields: initialState.addressFields
            };
        default:
            return state;
    }
};
const CheckoutProvider = (props)=>{
    const [state, dispatch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(checkoutReducer, initialState);
    const setCardFields = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((card)=>dispatch({
            type: "SET_CARD_FIELDS",
            card
        }), [
        dispatch
    ]);
    const setAddressFields = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((address)=>dispatch({
            type: "SET_ADDRESS_FIELDS",
            address
        }), [
        dispatch
    ]);
    const clearCheckoutFields = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>dispatch({
            type: "CLEAR_CHECKOUT_FIELDS"
        }), [
        dispatch
    ]);
    const cardFields = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>state.cardFields, [
        state.cardFields
    ]);
    const addressFields = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>state.addressFields, [
        state.addressFields
    ]);
    const value = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>({
            cardFields,
            addressFields,
            setCardFields,
            setAddressFields,
            clearCheckoutFields
        }), [
        cardFields,
        addressFields,
        setCardFields,
        setAddressFields,
        clearCheckoutFields
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CheckoutContext.Provider, {
        value: value,
        ...props
    });
};
const useCheckoutContext = ()=>{
    const context = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(CheckoutContext);
    if (context === undefined) {
        throw new Error(`useCheckoutContext must be used within a CheckoutProvider`);
    }
    return context;
};


/***/ }),

/***/ 9280:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Avatar_Avatar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/ui/context.tsx
var context = __webpack_require__(5409);
// EXTERNAL MODULE: ./lib/colors.ts
var colors = __webpack_require__(6550);
;// CONCATENATED MODULE: ./lib/hooks/useUserAvatar.ts



const useUserAvatar = (name = "userAvatar")=>{
    const { userAvatar , setUserAvatar  } = (0,context/* useUI */.l8)();
    (0,external_react_.useEffect)(()=>{
        if (!userAvatar && localStorage.getItem(name)) {
            // Get bg from localStorage and push it to the context.
            setUserAvatar(localStorage.getItem(name));
        }
        if (!localStorage.getItem(name)) {
            // bg not set locally, generating one, setting localStorage and context to persist.
            const bg = (0,colors/* getRandomPairOfColors */.uo)();
            const value = `linear-gradient(140deg, ${bg[0]}, ${bg[1]} 100%)`;
            localStorage.setItem(name, value);
            setUserAvatar(value);
        }
    }, [
        name,
        setUserAvatar,
        userAvatar
    ]);
    return {
        userAvatar,
        setUserAvatar
    };
};

;// CONCATENATED MODULE: ./components/common/Avatar/Avatar.tsx



const Avatar = ({})=>{
    let ref = (0,external_react_.useRef)();
    let { userAvatar  } = useUserAvatar();
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        ref: ref,
        style: {
            backgroundImage: userAvatar
        },
        className: "inline-block h-8 w-8 rounded-full border-2 border-primary hover:border-secondary focus:border-secondary transition-colors ease-linear"
    });
};
/* harmony default export */ const Avatar_Avatar = (Avatar);


/***/ }),

/***/ 3768:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1958);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lib_get_slug__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7240);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8162);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9322);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3203);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4393);
/* harmony import */ var _components_common__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4214);
/* harmony import */ var _components_ui_ThemeSwitcher__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1812);
/* harmony import */ var _Footer_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6880);
/* harmony import */ var _Footer_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Footer_module_css__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_ThemeSwitcher__WEBPACK_IMPORTED_MODULE_7__, _components_common__WEBPACK_IMPORTED_MODULE_8__]);
([_components_ui_ThemeSwitcher__WEBPACK_IMPORTED_MODULE_7__, _components_common__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










const links = [
    {
        name: "Home",
        url: "/"
    }
];
const Footer = ({ className , pages  })=>{
    const { sitePages  } = usePages(pages);
    const rootClassName = clsx__WEBPACK_IMPORTED_MODULE_1___default()((_Footer_module_css__WEBPACK_IMPORTED_MODULE_4___default().root), className);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("footer", {
        className: rootClassName,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "grid grid-cols-1 lg:grid-cols-12 gap-8 border-b border-accent-2 py-12 text-primary bg-primary transition-colors duration-150",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-span-1 lg:col-span-2",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                href: "/",
                                className: "flex flex-initial items-center font-bold md:mr-24",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "rounded-full border border-accent-6 mr-2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "ACME"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-span-1 lg:col-span-7",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "grid md:grid-rows-4 md:grid-cols-3 md:grid-flow-col",
                                children: [
                                    ...links,
                                    ...sitePages
                                ].map((page)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "py-3 md:py-0 md:pb-4",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: page.url,
                                            className: "text-accent-9 hover:text-accent-6 transition ease-in-out duration-150",
                                            children: page.name
                                        })
                                    }, page.url))
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-span-1 lg:col-span-3 flex items-start lg:justify-end text-primary",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex space-x-4 items-center h-10",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_ThemeSwitcher__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_4___default().link),
                                        "aria-label": "Github Repository",
                                        href: "https://github.com/vercel/commerce",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {})
                                    })
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "pt-6 pb-10 flex flex-col md:flex-row justify-between items-center space-y-4 text-accent-6 text-sm",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "\xa9 2020 ACME, Inc. All rights reserved."
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center text-primary text-sm",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "text-primary",
                                    children: "Created by"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    rel: "noopener noreferrer",
                                    href: "https://vercel.com",
                                    "aria-label": "Vercel.com Link",
                                    target: "_blank",
                                    className: "text-primary",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                        className: "inline-block h-6 ml-3 text-primary",
                                        alt: "Vercel.com Logo"
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
function usePages(pages) {
    const { locale  } = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const sitePages = [];
    if (pages) {
        pages.forEach((page)=>{
            const slug = page.url && (0,_lib_get_slug__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)(page.url);
            if (!slug) return;
            if (locale && !slug.startsWith(`${locale}/`)) return;
            sitePages.push(page);
        });
    }
    return {
        sitePages: sitePages.sort(bySortOrder)
    };
}
// Sort pages by the sort order assigned in the BC dashboard
function bySortOrder(a, b) {
    return (a.sort_order ?? 0) - (b.sort_order ?? 0);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4214:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1958);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _I18nWidget_module_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3269);
/* harmony import */ var _I18nWidget_module_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_I18nWidget_module_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6940);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1609);
/* harmony import */ var _lib_click_outside__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3458);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3558);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_click_outside__WEBPACK_IMPORTED_MODULE_6__]);
_lib_click_outside__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









const LOCALES_MAP = {
    es: {
        name: "Espa\xf1ol",
        img: {
            filename: "flag-es-co.svg",
            alt: "Bandera Colombiana"
        }
    },
    "en-US": {
        name: "English",
        img: {
            filename: "flag-en-us.svg",
            alt: "US Flag"
        }
    }
};
const I18nWidget = ()=>{
    const [display, setDisplay] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const { locale , locales , defaultLocale ="en-US" , asPath: currentPath  } = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const options = locales?.filter((val)=>val !== locale);
    const currentLocale = locale || defaultLocale;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_lib_click_outside__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
        active: display,
        onClick: ()=>setDisplay(false),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
            className: (_I18nWidget_module_css__WEBPACK_IMPORTED_MODULE_7___default().root),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex items-center relative",
                    onClick: ()=>setDisplay(!display),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        className: (_I18nWidget_module_css__WEBPACK_IMPORTED_MODULE_7___default().button),
                        "aria-label": "Language selector",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_5___default()), {
                                width: "20",
                                height: "20",
                                className: "block w-5",
                                src: `/${LOCALES_MAP[currentLocale].img.filename}`,
                                alt: LOCALES_MAP[currentLocale].img.alt,
                                unoptimized: true
                            }),
                            options && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "cursor-pointer ml-1",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                    className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_I18nWidget_module_css__WEBPACK_IMPORTED_MODULE_7___default().icon), {
                                        [(_I18nWidget_module_css__WEBPACK_IMPORTED_MODULE_7___default().active)]: display
                                    })
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "absolute top-0 right-0",
                    children: options?.length && display ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_I18nWidget_module_css__WEBPACK_IMPORTED_MODULE_7___default().dropdownMenu),
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex flex-row justify-end px-6",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    onClick: ()=>setDisplay(false),
                                    "aria-label": "Close panel",
                                    className: (_I18nWidget_module_css__WEBPACK_IMPORTED_MODULE_7___default().closeButton),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                        className: "h-6 w-6"
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                children: options.map((locale)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: currentPath,
                                            locale: locale,
                                            className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_I18nWidget_module_css__WEBPACK_IMPORTED_MODULE_7___default().item)),
                                            onClick: ()=>setDisplay(false),
                                            children: LOCALES_MAP[locale].name
                                        })
                                    }, locale))
                            })
                        ]
                    }) : null
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (I18nWidget);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2960:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Layout_module_css__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(3583);
/* harmony import */ var _Layout_module_css__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_Layout_module_css__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9025);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _framework__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1933);
/* harmony import */ var _components_auth_LoginView__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3368);
/* harmony import */ var _components_ui_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5409);
/* harmony import */ var _components_common__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2883);
/* harmony import */ var _components_common__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(3768);
/* harmony import */ var _components_checkout_ShippingView__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1966);
/* harmony import */ var _components_cart_CartSidebarView__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8457);
/* harmony import */ var _lib_hooks_useAcceptCookies__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2041);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(315);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7397);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(2261);
/* harmony import */ var _components_checkout_PaymentMethodView__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6321);
/* harmony import */ var _components_checkout_CheckoutSidebarView__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2670);
/* harmony import */ var _components_checkout_context__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(2361);
/* harmony import */ var _components_common_UserNav__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1219);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_auth_LoginView__WEBPACK_IMPORTED_MODULE_5__, _components_cart_CartSidebarView__WEBPACK_IMPORTED_MODULE_8__, _components_checkout_ShippingView__WEBPACK_IMPORTED_MODULE_9__, _components_checkout_PaymentMethodView__WEBPACK_IMPORTED_MODULE_10__, _components_checkout_CheckoutSidebarView__WEBPACK_IMPORTED_MODULE_11__, _components_common_UserNav__WEBPACK_IMPORTED_MODULE_12__, _lib_hooks_useAcceptCookies__WEBPACK_IMPORTED_MODULE_13__, _framework__WEBPACK_IMPORTED_MODULE_14__, _components_common__WEBPACK_IMPORTED_MODULE_16__, _components_common__WEBPACK_IMPORTED_MODULE_17__, _components_ui__WEBPACK_IMPORTED_MODULE_19__]);
([_components_auth_LoginView__WEBPACK_IMPORTED_MODULE_5__, _components_cart_CartSidebarView__WEBPACK_IMPORTED_MODULE_8__, _components_checkout_ShippingView__WEBPACK_IMPORTED_MODULE_9__, _components_checkout_PaymentMethodView__WEBPACK_IMPORTED_MODULE_10__, _components_checkout_CheckoutSidebarView__WEBPACK_IMPORTED_MODULE_11__, _components_common_UserNav__WEBPACK_IMPORTED_MODULE_12__, _lib_hooks_useAcceptCookies__WEBPACK_IMPORTED_MODULE_13__, _framework__WEBPACK_IMPORTED_MODULE_14__, _components_common__WEBPACK_IMPORTED_MODULE_16__, _components_common__WEBPACK_IMPORTED_MODULE_17__, _components_ui__WEBPACK_IMPORTED_MODULE_19__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















const Loading = ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-80 h-80 flex items-center text-center justify-center p-3",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {})
    });
const dynamicProps = {
    loading: Loading
};
const SignUpView = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(()=>__webpack_require__.e(/* import() */ 519).then(__webpack_require__.bind(__webpack_require__, 4519)), {
    loadableGenerated: {
        modules: [
            "../components/common/Layout/Layout.tsx -> " + "@components/auth/SignUpView"
        ]
    },
    ...dynamicProps
});
const ForgotPassword = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(()=>__webpack_require__.e(/* import() */ 739).then(__webpack_require__.bind(__webpack_require__, 739)), {
    loadableGenerated: {
        modules: [
            "../components/common/Layout/Layout.tsx -> " + "@components/auth/ForgotPassword"
        ]
    },
    ...dynamicProps
});
const FeatureBar = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(()=>__webpack_require__.e(/* import() */ 328).then(__webpack_require__.bind(__webpack_require__, 7328)), {
    loadableGenerated: {
        modules: [
            "../components/common/Layout/Layout.tsx -> " + "@components/common/FeatureBar"
        ]
    },
    ...dynamicProps
});
const Modal = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(()=>__webpack_require__.e(/* import() */ 91).then(__webpack_require__.bind(__webpack_require__, 7091)), {
    loadableGenerated: {
        modules: [
            "../components/common/Layout/Layout.tsx -> " + "@components/ui/Modal"
        ]
    },
    ...dynamicProps,
    ssr: false
});
const ModalView = ({ modalView , closeModal  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Modal, {
        onClose: closeModal,
        children: [
            modalView === "LOGIN_VIEW" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_auth_LoginView__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {}),
            modalView === "SIGNUP_VIEW" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SignUpView, {}),
            modalView === "FORGOT_VIEW" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ForgotPassword, {})
        ]
    });
};
const ModalUI = ()=>{
    const { displayModal , closeModal , modalView  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_6__/* .useUI */ .l8)();
    return displayModal ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ModalView, {
        modalView: modalView,
        closeModal: closeModal
    }) : null;
};
const SidebarView = ({ sidebarView , closeSidebar , links  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
        onClose: closeSidebar,
        children: [
            sidebarView === "CART_VIEW" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_cart_CartSidebarView__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
            sidebarView === "SHIPPING_VIEW" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_checkout_ShippingView__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
            sidebarView === "PAYMENT_VIEW" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_checkout_PaymentMethodView__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}),
            sidebarView === "CHECKOUT_VIEW" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_checkout_CheckoutSidebarView__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {}),
            sidebarView === "MOBILE_MENU_VIEW" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_UserNav__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                links: links
            })
        ]
    });
};
const SidebarUI = ({ links  })=>{
    const { displaySidebar , closeSidebar , sidebarView  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_6__/* .useUI */ .l8)();
    return displaySidebar ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SidebarView, {
        links: links,
        sidebarView: sidebarView,
        closeSidebar: closeSidebar
    }) : null;
};
const Layout = ({ children , pageProps: { categories =[] , ...pageProps }  })=>{
    const { acceptedCookies , onAcceptCookies  } = (0,_lib_hooks_useAcceptCookies__WEBPACK_IMPORTED_MODULE_13__/* .useAcceptCookies */ .X)();
    const { locale ="en-US"  } = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const navBarlinks = categories.slice(0, 2).map((c)=>({
            label: c.name,
            href: `/search/${c.slug}`
        }));
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_framework__WEBPACK_IMPORTED_MODULE_14__/* .CommerceProvider */ .SN, {
        locale: locale,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_Layout_module_css__WEBPACK_IMPORTED_MODULE_15___default().root)),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                    links: navBarlinks
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                    className: "fit",
                    children: children
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                    pages: pageProps.pages
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ModalUI, {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_checkout_context__WEBPACK_IMPORTED_MODULE_18__/* .CheckoutProvider */ .oo, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SidebarUI, {
                        links: navBarlinks
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FeatureBar, {
                    title: "This site uses cookies to improve your experience. By clicking, you agree to our Privacy Policy.",
                    hide: acceptedCookies,
                    action: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                        className: "mx-5",
                        onClick: ()=>onAcceptCookies(),
                        children: "Accept cookies"
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2883:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1958);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Navbar_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9786);
/* harmony import */ var _Navbar_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Navbar_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _NavbarRoot__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6106);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3203);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4393);
/* harmony import */ var _components_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1715);
/* harmony import */ var _components_common__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2608);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common__WEBPACK_IMPORTED_MODULE_7__]);
_components_common__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const Navbar = ({ links  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_NavbarRoot__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            clean: true,
            className: "mx-auto max-w-8xl px-6",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_Navbar_module_css__WEBPACK_IMPORTED_MODULE_4___default().nav),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex items-center flex-1",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    href: "/",
                                    className: (_Navbar_module_css__WEBPACK_IMPORTED_MODULE_4___default().logo),
                                    "aria-label": "Logo",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("nav", {
                                    className: (_Navbar_module_css__WEBPACK_IMPORTED_MODULE_4___default().navMenu),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            href: "/search",
                                            className: (_Navbar_module_css__WEBPACK_IMPORTED_MODULE_4___default().link),
                                            children: "All"
                                        }),
                                        links?.map((l)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                href: l.href,
                                                className: (_Navbar_module_css__WEBPACK_IMPORTED_MODULE_4___default().link),
                                                children: l.label
                                            }, l.href))
                                    ]
                                })
                            ]
                        }),
                        process.env.COMMERCE_SEARCH_ENABLED && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "justify-center flex-1 hidden lg:flex",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex items-center justify-end flex-1 space-x-8",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {})
                        })
                    ]
                }),
                process.env.COMMERCE_SEARCH_ENABLED && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex pb-4 lg:px-6 lg:hidden",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        id: "mobile-search"
                    })
                })
            ]
        })
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Navbar);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6106:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash_throttle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8622);
/* harmony import */ var lodash_throttle__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_throttle__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Navbar_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9786);
/* harmony import */ var _Navbar_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Navbar_module_css__WEBPACK_IMPORTED_MODULE_4__);





const NavbarRoot = ({ children  })=>{
    const [hasScrolled, setHasScrolled] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const handleScroll = lodash_throttle__WEBPACK_IMPORTED_MODULE_2___default()(()=>{
            const offset = 0;
            const { scrollTop  } = document.documentElement;
            const scrolled = scrollTop > offset;
            if (hasScrolled !== scrolled) {
                setHasScrolled(scrolled);
            }
        }, 200);
        document.addEventListener("scroll", handleScroll);
        return ()=>{
            document.removeEventListener("scroll", handleScroll);
        };
    }, [
        hasScrolled
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_3___default()((_Navbar_module_css__WEBPACK_IMPORTED_MODULE_4___default().root), {
            "shadow-magical": hasScrolled
        }),
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NavbarRoot);


/***/ }),

/***/ 1715:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Searchbar_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1628);
/* harmony import */ var _Searchbar_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Searchbar_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);





const Searchbar = ({ className , id ="search"  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        router.prefetch("/search");
    }, [
        router
    ]);
    const handleKeyUp = (e)=>{
        e.preventDefault();
        if (e.key === "Enter") {
            const q = e.currentTarget.value;
            router.push({
                pathname: `/search`,
                query: q ? {
                    q
                } : {}
            }, undefined, {
                shallow: true
            });
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()((_Searchbar_module_css__WEBPACK_IMPORTED_MODULE_4___default().root), className),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                className: "hidden",
                htmlFor: id,
                children: "Search"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                id: id,
                className: (_Searchbar_module_css__WEBPACK_IMPORTED_MODULE_4___default().input),
                placeholder: "Search for products...",
                defaultValue: router.query.q,
                onKeyUp: handleKeyUp
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_Searchbar_module_css__WEBPACK_IMPORTED_MODULE_4___default().iconContainer),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                    className: (_Searchbar_module_css__WEBPACK_IMPORTED_MODULE_4___default().icon),
                    fill: "currentColor",
                    viewBox: "0 0 20 20",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.memo)(Searchbar));


/***/ }),

/***/ 6794:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1609);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7315);
/* harmony import */ var _components_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2608);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _SidebarLayout_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4228);
/* harmony import */ var _SidebarLayout_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_SidebarLayout_module_css__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common__WEBPACK_IMPORTED_MODULE_6__]);
_components_common__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const SidebarLayout = ({ children , className , handleBack , handleClose  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()((_SidebarLayout_module_css__WEBPACK_IMPORTED_MODULE_3___default().root), className),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("header", {
                className: (_SidebarLayout_module_css__WEBPACK_IMPORTED_MODULE_3___default().header),
                children: [
                    handleClose && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        onClick: handleClose,
                        "aria-label": "Close",
                        className: "hover:text-accent-5 transition ease-in-out duration-150 flex items-center focus:outline-none mr-6",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                className: "h-6 w-6 hover:text-accent-3"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "ml-2 text-accent-7 text-sm ",
                                children: "Close"
                            })
                        ]
                    }),
                    handleBack && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        onClick: handleBack,
                        "aria-label": "Go back",
                        className: "hover:text-accent-5 transition ease-in-out duration-150 flex items-center focus:outline-none",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                className: "h-6 w-6 hover:text-accent-3"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "ml-2 text-accent-7 text-xs",
                                children: "Back"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_SidebarLayout_module_css__WEBPACK_IMPORTED_MODULE_3___default().container),
                children: children
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SidebarLayout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7002:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CustomerMenuContent)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_themes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1162);
/* harmony import */ var next_themes__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_themes__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4696);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(143);
/* harmony import */ var _CustomerMenuContent_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5418);
/* harmony import */ var _CustomerMenuContent_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_CustomerMenuContent_module_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _framework_auth_use_logout__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6667);
/* harmony import */ var _components_ui_Dropdown_Dropdown__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8595);








const LINKS = [
    {
        name: "My Orders",
        href: "/orders"
    },
    {
        name: "My Profile",
        href: "/profile"
    },
    {
        name: "My Cart",
        href: "/cart"
    }
];
function CustomerMenuContent() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const logout = (0,_framework_auth_use_logout__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const { pathname  } = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const { theme , setTheme  } = (0,next_themes__WEBPACK_IMPORTED_MODULE_2__.useTheme)();
    function handleClick(_, href) {
        router.push(href);
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui_Dropdown_Dropdown__WEBPACK_IMPORTED_MODULE_5__/* .DropdownContent */ .Nv, {
        asChild: true,
        side: "bottom",
        sideOffset: 10,
        className: (_CustomerMenuContent_module_css__WEBPACK_IMPORTED_MODULE_6___default().root),
        id: "CustomerMenuContent",
        children: [
            LINKS.map(({ name , href  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_Dropdown_Dropdown__WEBPACK_IMPORTED_MODULE_5__/* .DropdownMenuItem */ .Xi, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_CustomerMenuContent_module_css__WEBPACK_IMPORTED_MODULE_6___default().link), {
                            [(_CustomerMenuContent_module_css__WEBPACK_IMPORTED_MODULE_6___default().active)]: pathname === href
                        }),
                        onClick: (e)=>handleClick(e, href),
                        children: name
                    })
                }, href)),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_Dropdown_Dropdown__WEBPACK_IMPORTED_MODULE_5__/* .DropdownMenuItem */ .Xi, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                    className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_CustomerMenuContent_module_css__WEBPACK_IMPORTED_MODULE_6___default().link), "justify-between"),
                    onClick: ()=>{
                        setTheme(theme === "dark" ? "light" : "dark");
                    },
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                "Theme: ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("strong", {
                                    children: theme
                                }),
                                " "
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "ml-3",
                            children: theme == "dark" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                width: 20,
                                height: 20
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                width: 20,
                                height: 20
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_Dropdown_Dropdown__WEBPACK_IMPORTED_MODULE_5__/* .DropdownMenuItem */ .Xi, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                    className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_CustomerMenuContent_module_css__WEBPACK_IMPORTED_MODULE_6___default().link), "border-t border-accent-2 mt-4"),
                    onClick: ()=>logout(),
                    children: "Logout"
                })
            })
        ]
    });
}


/***/ }),

/***/ 1219:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ MenuSidebarView)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1958);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _MenuSidebarView_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1112);
/* harmony import */ var _MenuSidebarView_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_MenuSidebarView_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_ui_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5409);
/* harmony import */ var _components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6794);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_3__]);
_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function MenuSidebarView({ links =[]  }) {
    const { closeSidebar  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_2__/* .useUI */ .l8)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common_SidebarLayout__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
        handleClose: ()=>closeSidebar(),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_MenuSidebarView_module_css__WEBPACK_IMPORTED_MODULE_4___default().root),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                            className: (_MenuSidebarView_module_css__WEBPACK_IMPORTED_MODULE_4___default().item),
                            onClick: ()=>closeSidebar(),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: "/search",
                                children: "All"
                            })
                        }),
                        links.map((l)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: (_MenuSidebarView_module_css__WEBPACK_IMPORTED_MODULE_4___default().item),
                                onClick: ()=>closeSidebar(),
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    href: l.href,
                                    children: l.label
                                })
                            }, l.href))
                    ]
                })
            })
        })
    });
}
MenuSidebarView;

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2608:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1958);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _UserNav_module_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3317);
/* harmony import */ var _UserNav_module_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_UserNav_module_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_common__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9280);
/* harmony import */ var _framework_cart_use_cart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6973);
/* harmony import */ var _components_ui_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5409);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8663);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4981);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1635);
/* harmony import */ var _CustomerMenuContent__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7002);
/* harmony import */ var _framework_customer_use_customer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6999);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8595);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2261);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_framework_cart_use_cart__WEBPACK_IMPORTED_MODULE_4__, _components_ui__WEBPACK_IMPORTED_MODULE_9__]);
([_framework_cart_use_cart__WEBPACK_IMPORTED_MODULE_4__, _components_ui__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const countItem = (count, item)=>count + item.quantity;
const UserNav = ({ className  })=>{
    const { data  } = (0,_framework_cart_use_cart__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)();
    const { data: isCustomerLoggedIn  } = (0,_framework_customer_use_customer__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z)();
    const { toggleSidebar , closeSidebarIfPresent , openModal , setSidebarView , openSidebar  } = (0,_components_ui_context__WEBPACK_IMPORTED_MODULE_6__/* .useUI */ .l8)();
    const itemsCount = data?.lineItems?.reduce(countItem, 0) ?? 0;
    const DropdownTrigger = isCustomerLoggedIn ? _components_ui__WEBPACK_IMPORTED_MODULE_7__/* .DropdownTrigger */ .WA : (react__WEBPACK_IMPORTED_MODULE_3___default().Fragment);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
        className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_UserNav_module_css__WEBPACK_IMPORTED_MODULE_8___default().root), className),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
            className: (_UserNav_module_css__WEBPACK_IMPORTED_MODULE_8___default().list),
            children: [
                process.env.COMMERCE_CART_ENABLED && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    className: (_UserNav_module_css__WEBPACK_IMPORTED_MODULE_8___default().item),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        className: (_UserNav_module_css__WEBPACK_IMPORTED_MODULE_8___default().item),
                        variant: "naked",
                        onClick: ()=>{
                            setSidebarView("CART_VIEW");
                            openSidebar();
                        },
                        "aria-label": `Cart items: ${itemsCount}`,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}),
                            itemsCount > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: (_UserNav_module_css__WEBPACK_IMPORTED_MODULE_8___default().bagCount),
                                children: itemsCount
                            })
                        ]
                    })
                }),
                process.env.COMMERCE_WISHLIST_ENABLED && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    className: (_UserNav_module_css__WEBPACK_IMPORTED_MODULE_8___default().item),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                        href: "/wishlist",
                        legacyBehavior: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            onClick: closeSidebarIfPresent,
                            "aria-label": "Wishlist",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                        })
                    })
                }),
                process.env.COMMERCE_CUSTOMERAUTH_ENABLED && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    className: (_UserNav_module_css__WEBPACK_IMPORTED_MODULE_8___default().item),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_components_ui__WEBPACK_IMPORTED_MODULE_7__/* .Dropdown */ .Lt, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DropdownTrigger, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    "aria-label": "Menu",
                                    className: (_UserNav_module_css__WEBPACK_IMPORTED_MODULE_8___default().avatarButton),
                                    onClick: ()=>isCustomerLoggedIn ? null : openModal(),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_common__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {})
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomerMenuContent__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {})
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                    className: (_UserNav_module_css__WEBPACK_IMPORTED_MODULE_8___default().mobileMenu),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                        className: (_UserNav_module_css__WEBPACK_IMPORTED_MODULE_8___default().item),
                        "aria-label": "Menu",
                        variant: "naked",
                        onClick: ()=>{
                            setSidebarView("MOBILE_MENU_VIEW");
                            openSidebar();
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {})
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UserNav);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8663:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Bag = ({ ...props })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        width: "20",
        height: "22",
        viewBox: "0 0 20 22",
        fill: "none",
        stroke: "currentColor",
        ...props,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M4 1L1 5V19C1 19.5304 1.21071 20.0391 1.58579 20.4142C1.96086 20.7893 2.46957 21 3 21H17C17.5304 21 18.0391 20.7893 18.4142 20.4142C18.7893 20.0391 19 19.5304 19 19V5L16 1H4Z",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M1 5H19",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M14 9C14 10.0609 13.5786 11.0783 12.8284 11.8284C12.0783 12.5786 11.0609 13 10 13C8.93913 13 7.92172 12.5786 7.17157 11.8284C6.42143 11.0783 6 10.0609 6 9",
                strokeWidth: "1.5",
                strokeLinecap: "round",
                strokeLinejoin: "round"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Bag);


/***/ }),

/***/ 7225:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Check = ({ ...props })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: "currentColor",
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M20 6L9 17L4 12",
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Check);


/***/ }),

/***/ 7315:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const ChevronLeft = ({ ...props })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        viewBox: "0 0 24 24",
        width: "24",
        height: "24",
        stroke: "currentColor",
        strokeWidth: "1.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none",
        shapeRendering: "geometricPrecision",
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M15 18l-6-6 6-6"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChevronLeft);


/***/ }),

/***/ 6940:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const ChevronRight = ({ ...props })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        viewBox: "0 0 24 24",
        width: "24",
        height: "24",
        stroke: "currentColor",
        strokeWidth: "1.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none",
        shapeRendering: "geometricPrecision",
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M9 18l6-6-6-6"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChevronRight);


/***/ }),

/***/ 4259:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const CreditCard = ({ ...props })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        viewBox: "0 0 24 24",
        width: "24",
        height: "24",
        stroke: "currentColor",
        strokeWidth: "1.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none",
        shapeRendering: "geometricPrecision",
        ...props,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                x: "1",
                y: "4",
                width: "22",
                height: "16",
                rx: "2",
                ry: "2"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M1 10h22"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreditCard);


/***/ }),

/***/ 1609:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Cross = ({ ...props })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        viewBox: "0 0 24 24",
        width: "24",
        height: "24",
        stroke: "currentColor",
        strokeWidth: "1.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none",
        shapeRendering: "geometricPrecision",
        ...props,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M18 6L6 18"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M6 6l12 12"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Cross);


/***/ }),

/***/ 8162:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Github = ({ ...props })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        width: "24",
        height: "24",
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            fillRule: "evenodd",
            clipRule: "evenodd",
            d: "M12 0C5.37 0 0 5.50583 0 12.3035C0 17.7478 3.435 22.3463 8.205 23.9765C8.805 24.0842 9.03 23.715 9.03 23.3921C9.03 23.0999 9.015 22.131 9.015 21.1005C6 21.6696 5.22 20.347 4.98 19.6549C4.845 19.3012 4.26 18.2092 3.75 17.917C3.33 17.6863 2.73 17.1173 3.735 17.1019C4.68 17.0865 5.355 17.9939 5.58 18.363C6.66 20.2239 8.385 19.701 9.075 19.3781C9.18 18.5783 9.495 18.04 9.84 17.7325C7.17 17.4249 4.38 16.3637 4.38 11.6576C4.38 10.3196 4.845 9.21227 5.61 8.35102C5.49 8.04343 5.07 6.78232 5.73 5.09058C5.73 5.09058 6.735 4.76762 9.03 6.3517C9.99 6.07487 11.01 5.93645 12.03 5.93645C13.05 5.93645 14.07 6.07487 15.03 6.3517C17.325 4.75224 18.33 5.09058 18.33 5.09058C18.99 6.78232 18.57 8.04343 18.45 8.35102C19.215 9.21227 19.68 10.3042 19.68 11.6576C19.68 16.3791 16.875 17.4249 14.205 17.7325C14.64 18.1169 15.015 18.8552 15.015 20.0086C15.015 21.6542 15 22.9768 15 23.3921C15 23.715 15.225 24.0995 15.825 23.9765C18.2072 23.1519 20.2773 21.5822 21.7438 19.4882C23.2103 17.3942 23.9994 14.8814 24 12.3035C24 5.50583 18.63 0 12 0Z",
            fill: "currentColor"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Github);


/***/ }),

/***/ 4981:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Heart = ({ ...props })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        width: "24",
        height: "20",
        viewBox: "0 0 24 20",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M20.84 2.61C20.3292 2.099 19.7228 1.69365 19.0554 1.41708C18.3879 1.14052 17.6725 0.998175 16.95 0.998175C16.2275 0.998175 15.5121 1.14052 14.8446 1.41708C14.1772 1.69365 13.5708 2.099 13.06 2.61L12 3.67L10.94 2.61C9.9083 1.57831 8.50903 0.998709 7.05 0.998709C5.59096 0.998709 4.19169 1.57831 3.16 2.61C2.1283 3.64169 1.54871 5.04097 1.54871 6.5C1.54871 7.95903 2.1283 9.35831 3.16 10.39L4.22 11.45L12 19.23L19.78 11.45L20.84 10.39C21.351 9.87924 21.7563 9.27281 22.0329 8.60536C22.3095 7.9379 22.4518 7.22249 22.4518 6.5C22.4518 5.77751 22.3095 5.0621 22.0329 4.39464C21.7563 3.72719 21.351 3.12076 20.84 2.61V2.61Z",
            stroke: "currentColor",
            strokeWidth: "1.5",
            strokeLinecap: "round",
            strokeLinejoin: "round"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Heart);


/***/ }),

/***/ 7131:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const MapPin = ({ ...props })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        viewBox: "0 0 24 24",
        width: "24",
        height: "24",
        stroke: "currentColor",
        strokeWidth: "1.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none",
        shapeRendering: "geometricPrecision",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                cx: "12",
                cy: "10",
                r: "3"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MapPin);


/***/ }),

/***/ 1635:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Menu = ({ ...props })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        className: "h-6 w-6",
        fill: "none",
        viewBox: "0 0 24 24",
        stroke: "currentColor",
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: 2,
            d: "M4 6h16M4 12h16m-7 6h7"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Menu);


/***/ }),

/***/ 4696:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Moon = ({ ...props })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        viewBox: "0 0 24 24",
        width: "24",
        height: "24",
        stroke: "currentColor",
        strokeWidth: "1.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none",
        shapeRendering: "geometricPrecision",
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Moon);


/***/ }),

/***/ 143:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Sun = ({ ...props })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        viewBox: "0 0 24 24",
        width: "24",
        height: "24",
        stroke: "currentColor",
        strokeWidth: "1.5",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        fill: "none",
        shapeRendering: "geometricPrecision",
        ...props,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                cx: "12",
                cy: "12",
                r: "5"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M12 1v2"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M12 21v2"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M4.22 4.22l1.42 1.42"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M18.36 18.36l1.42 1.42"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M1 12h2"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M21 12h2"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M4.22 19.78l1.42-1.42"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M18.36 5.64l1.42-1.42"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Sun);


/***/ }),

/***/ 9322:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Vercel = ({ ...props })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        width: "89",
        height: "20",
        viewBox: "0 0 89 20",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        ...props,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M11.5625 0L23.125 20H0L11.5625 0Z",
                fill: "currentColor"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M49.875 10.625C49.875 7.40625 47.5 5.15625 44.0937 5.15625C40.6875 5.15625 38.3125 7.40625 38.3125 10.625C38.3125 13.7812 40.875 16.0937 44.4062 16.0937C46.3438 16.0937 48.0938 15.375 49.2188 14.0625L47.0938 12.8437C46.4375 13.5 45.4688 13.9062 44.4062 13.9062C42.8438 13.9062 41.5 13.0625 41.0312 11.7812L40.9375 11.5625H49.7812C49.8438 11.25 49.875 10.9375 49.875 10.625ZM40.9062 9.6875L40.9688 9.5C41.375 8.15625 42.5625 7.34375 44.0625 7.34375C45.5938 7.34375 46.75 8.15625 47.1562 9.5L47.2188 9.6875H40.9062Z",
                fill: "currentColor"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M83.5313 10.625C83.5313 7.40625 81.1563 5.15625 77.75 5.15625C74.3438 5.15625 71.9688 7.40625 71.9688 10.625C71.9688 13.7812 74.5313 16.0937 78.0625 16.0937C80 16.0937 81.75 15.375 82.875 14.0625L80.75 12.8437C80.0938 13.5 79.125 13.9062 78.0625 13.9062C76.5 13.9062 75.1563 13.0625 74.6875 11.7812L74.5938 11.5625H83.4375C83.5 11.25 83.5313 10.9375 83.5313 10.625ZM74.5625 9.6875L74.625 9.5C75.0313 8.15625 76.2188 7.34375 77.7188 7.34375C79.25 7.34375 80.4063 8.15625 80.8125 9.5L80.875 9.6875H74.5625Z",
                fill: "currentColor"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M68.5313 8.84374L70.6563 7.62499C69.6563 6.06249 67.875 5.18749 65.7188 5.18749C62.3125 5.18749 59.9375 7.43749 59.9375 10.6562C59.9375 13.875 62.3125 16.125 65.7188 16.125C67.875 16.125 69.6563 15.25 70.6563 13.6875L68.5313 12.4687C67.9688 13.4062 66.9688 13.9375 65.7188 13.9375C63.75 13.9375 62.4375 12.625 62.4375 10.6562C62.4375 8.68749 63.75 7.37499 65.7188 7.37499C66.9375 7.37499 67.9688 7.90624 68.5313 8.84374Z",
                fill: "currentColor"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M88.2188 1.75H85.7188V15.8125H88.2188V1.75Z",
                fill: "currentColor"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M40.1563 1.75H37.2813L31.7813 11.25L26.2813 1.75H23.375L31.7813 16.25L40.1563 1.75Z",
                fill: "currentColor"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M57.8438 8.0625C58.125 8.0625 58.4062 8.09375 58.6875 8.15625V5.5C56.5625 5.5625 54.5625 6.75 54.5625 8.21875V5.5H52.0625V15.8125H54.5625V11.3437C54.5625 9.40625 55.9062 8.0625 57.8438 8.0625Z",
                fill: "currentColor"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Vercel);


/***/ }),

/***/ 2261:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_merge_refs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8230);
/* harmony import */ var _Button_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5273);
/* harmony import */ var _Button_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Button_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_ui__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(315);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_merge_refs__WEBPACK_IMPORTED_MODULE_3__]);
react_merge_refs__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






// eslint-disable-next-line react/display-name
const Button = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_2__.forwardRef)((props, buttonRef)=>{
    const { className , variant ="flat" , children , active , width , loading =false , disabled =false , style ={} , Component ="button" , ...rest } = props;
    const ref = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    const rootClassName = clsx__WEBPACK_IMPORTED_MODULE_1___default()((_Button_module_css__WEBPACK_IMPORTED_MODULE_4___default().root), {
        [(_Button_module_css__WEBPACK_IMPORTED_MODULE_4___default().ghost)]: variant === "ghost",
        [(_Button_module_css__WEBPACK_IMPORTED_MODULE_4___default().slim)]: variant === "slim",
        [(_Button_module_css__WEBPACK_IMPORTED_MODULE_4___default().naked)]: variant === "naked",
        [(_Button_module_css__WEBPACK_IMPORTED_MODULE_4___default().loading)]: loading,
        [(_Button_module_css__WEBPACK_IMPORTED_MODULE_4___default().disabled)]: disabled
    }, className);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Component, {
        "aria-pressed": active,
        "data-variant": variant,
        ref: (0,react_merge_refs__WEBPACK_IMPORTED_MODULE_3__.mergeRefs)([
            ref,
            buttonRef
        ]),
        className: rootClassName,
        disabled: disabled,
        style: {
            width,
            ...style
        },
        ...rest,
        children: [
            children,
            loading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                className: "pl-2 m-0 flex",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {})
            })
        ]
    });
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Button);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3203:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const Container = ({ children , className , el ="div" , clean =false  })=>{
    const rootClassName = clsx__WEBPACK_IMPORTED_MODULE_1___default()(className, {
        "mx-auto max-w-7xl px-6 w-full": !clean
    });
    let Component = el;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
        className: rootClassName,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Container);


/***/ }),

/***/ 8595:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Lt": () => (/* binding */ Dropdown),
/* harmony export */   "Nv": () => (/* binding */ DropdownContent),
/* harmony export */   "WA": () => (/* binding */ DropdownTrigger),
/* harmony export */   "Xi": () => (/* binding */ DropdownMenuItem)
/* harmony export */ });
/* unused harmony exports DropdownMenuLabel, DropdownMenuGroup */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Dropdown_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7707);
/* harmony import */ var _Dropdown_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Dropdown_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8532);
/* harmony import */ var _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__);





const Dropdown = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Root;
const DropdownMenuItem = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Item;
const DropdownTrigger = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Trigger;
const DropdownMenuLabel = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Label;
const DropdownMenuGroup = _radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Group;
const DropdownContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_2___default().forwardRef(function DropdownContent({ children , className , ...props }, forwardedRef) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_dropdown_menu__WEBPACK_IMPORTED_MODULE_3__.Content, {
        ref: forwardedRef,
        sideOffset: 8,
        ...props,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_Dropdown_module_css__WEBPACK_IMPORTED_MODULE_4___default().root), className),
            children: children
        })
    });
});


/***/ }),

/***/ 5736:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Input_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5621);
/* harmony import */ var _Input_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_Input_module_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);




const Input = (props)=>{
    const { className , children , onChange , ...rest } = props;
    const rootClassName = clsx__WEBPACK_IMPORTED_MODULE_1___default()((_Input_module_css__WEBPACK_IMPORTED_MODULE_3___default().root), {}, className);
    const handleOnChange = (e)=>{
        if (onChange) {
            onChange(e.target.value);
        }
        return null;
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
            className: rootClassName,
            onChange: handleOnChange,
            autoComplete: "off",
            autoCorrect: "off",
            autoCapitalize: "off",
            spellCheck: "false",
            ...rest
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Input);


/***/ }),

/***/ 315:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _LoadingDots_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1852);
/* harmony import */ var _LoadingDots_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_LoadingDots_module_css__WEBPACK_IMPORTED_MODULE_1__);


const LoadingDots = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
        className: (_LoadingDots_module_css__WEBPACK_IMPORTED_MODULE_1___default().root),
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: (_LoadingDots_module_css__WEBPACK_IMPORTED_MODULE_1___default().dot)
            }, `dot_1`),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: (_LoadingDots_module_css__WEBPACK_IMPORTED_MODULE_1___default().dot)
            }, `dot_2`),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                className: (_LoadingDots_module_css__WEBPACK_IMPORTED_MODULE_1___default().dot)
            }, `dot_3`)
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LoadingDots);


/***/ }),

/***/ 4393:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Logo = ({ className ="" , ...props })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        width: "32",
        height: "32",
        viewBox: "0 0 32 32",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        className: className,
        ...props,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                width: "100%",
                height: "100%",
                rx: "16",
                fill: "var(--secondary)"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M17.6482 10.1305L15.8785 7.02583L7.02979 22.5499H10.5278L17.6482 10.1305ZM19.8798 14.0457L18.11 17.1983L19.394 19.4511H16.8453L15.1056 22.5499H24.7272L19.8798 14.0457Z",
                fill: "var(--primary)"
            })
        ]
    });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Logo);


/***/ }),

/***/ 7397:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Sidebar_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8718);
/* harmony import */ var _Sidebar_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var body_scroll_lock__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5782);
/* harmony import */ var body_scroll_lock__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(body_scroll_lock__WEBPACK_IMPORTED_MODULE_3__);





const Sidebar = ({ children , onClose  })=>{
    const sidebarRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)();
    const contentRef = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)();
    const onKeyDownSidebar = (event)=>{
        if (event.code === "Escape") {
            onClose();
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (sidebarRef.current) {
            sidebarRef.current.focus();
        }
        const contentElement = contentRef.current;
        if (contentElement) {
            (0,body_scroll_lock__WEBPACK_IMPORTED_MODULE_3__.disableBodyScroll)(contentElement, {
                reserveScrollBarGap: true
            });
        }
        return ()=>{
            (0,body_scroll_lock__WEBPACK_IMPORTED_MODULE_3__.clearAllBodyScrollLocks)();
        };
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: clsx__WEBPACK_IMPORTED_MODULE_1___default()((_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_4___default().root)),
        ref: sidebarRef,
        onKeyDown: onKeyDownSidebar,
        tabIndex: 1,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "absolute inset-0 overflow-hidden",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_4___default().backdrop),
                    onClick: onClose
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                    className: "absolute inset-y-0 right-0 w-full md:w-auto max-w-full flex outline-none md:pl-10",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "h-full w-full md:w-screen md:max-w-md",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_Sidebar_module_css__WEBPACK_IMPORTED_MODULE_4___default().sidebar),
                            ref: contentRef,
                            children: children
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Sidebar);


/***/ }),

/***/ 4084:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Text_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9054);
/* harmony import */ var _Text_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_Text_module_css__WEBPACK_IMPORTED_MODULE_3__);




const Text = ({ style , className ="" , variant ="body" , children , html , onClick  })=>{
    const componentsMap = {
        body: "div",
        heading: "h1",
        pageHeading: "h1",
        sectionHeading: "h2"
    };
    const Component = componentsMap[variant];
    const htmlContentProps = html ? {
        dangerouslySetInnerHTML: {
            __html: html
        }
    } : {};
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()((_Text_module_css__WEBPACK_IMPORTED_MODULE_3___default().root), {
            [(_Text_module_css__WEBPACK_IMPORTED_MODULE_3___default().body)]: variant === "body",
            [(_Text_module_css__WEBPACK_IMPORTED_MODULE_3___default().heading)]: variant === "heading",
            [(_Text_module_css__WEBPACK_IMPORTED_MODULE_3___default().pageHeading)]: variant === "pageHeading",
            [(_Text_module_css__WEBPACK_IMPORTED_MODULE_3___default().sectionHeading)]: variant === "sectionHeading"
        }, className),
        onClick: onClick,
        style: style,
        ...htmlContentProps,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Text);


/***/ }),

/***/ 9129:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ ThemeSwitcher_ThemeIcon)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./components/icons/Sun.tsx
var Sun = __webpack_require__(143);
// EXTERNAL MODULE: ./components/icons/Moon.tsx
var Moon = __webpack_require__(4696);
;// CONCATENATED MODULE: ./components/icons/System.tsx

const System = ({ ...props })=>/*#__PURE__*/ jsx_runtime_.jsx("svg", {
        "data-testid": "geist-icon",
        fill: "none",
        height: "16",
        shapeRendering: "geometricPrecision",
        stroke: "currentColor",
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "1.5",
        viewBox: "0 0 24 24",
        className: "text-current",
        ...props,
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M2 13.381h20M8.66 19.05V22m6.84-2.95V22m-8.955 0h10.932M4 19.05h16a2 2 0 002-2V4a2 2 0 00-2-2H4a2 2 0 00-2 2v13.05a2 2 0 002 2z"
        })
    });
/* harmony default export */ const icons_System = (System);

;// CONCATENATED MODULE: ./components/ui/ThemeSwitcher/ThemeIcon.tsx


const ThemeIcon = ({ theme , ...props })=>{
    switch(theme){
        case "light":
            return /*#__PURE__*/ jsx_runtime_.jsx(Sun/* default */.Z, {
                ...props
            });
        case "dark":
            return /*#__PURE__*/ jsx_runtime_.jsx(Moon/* default */.Z, {
                ...props
            });
        default:
            return /*#__PURE__*/ jsx_runtime_.jsx(icons_System, {
                ...props
            });
    }
};
/* harmony default export */ const ThemeSwitcher_ThemeIcon = (ThemeIcon);


/***/ }),

/***/ 1812:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6940);
/* harmony import */ var _components_icons__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1609);
/* harmony import */ var _lib_hooks_useToggleTheme__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6422);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8103);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lib_click_outside__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3458);
/* harmony import */ var _ThemeIcon__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9129);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_lib_click_outside__WEBPACK_IMPORTED_MODULE_4__]);
_lib_click_outside__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const ThemeSwitcher = ()=>{
    const [display, setDisplay] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { theme , themes , setTheme  } = (0,_lib_hooks_useToggleTheme__WEBPACK_IMPORTED_MODULE_3__/* .useToggleTheme */ .I)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_lib_click_outside__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        active: display,
        onClick: ()=>setDisplay(false),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "relative",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex items-center relative",
                    onClick: ()=>setDisplay(!display),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        className: "w-[125px] h-10 pl-2 pr-1 rounded-md border border-accent-2 flex items-center justify-between transition-colors ease-linear hover:border-accent-3 hover:shadow-sm",
                        "aria-label": "Theme Switcher",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "flex flex-shrink items-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ThemeIcon__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                        width: 20,
                                        height: 20,
                                        theme: theme
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("capitalize leading-none ml-2"),
                                        children: theme
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "cursor-pointer",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                    className: clsx__WEBPACK_IMPORTED_MODULE_2___default()("transition duration-300", {
                                        ["rotate-90"]: display
                                    })
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "absolute top-0 right-0",
                    children: themes.length && display ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "fixed shadow-lg right-0 top-12 mt-2 origin-top-right w-full h-full outline-none bg-accent-0 z-40 lg:absolute lg:border lg:border-accent-1 lg:shadow-lg lg:w-56 lg:h-auto",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex flex-row justify-end px-6",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "md:hidden",
                                    onClick: ()=>setDisplay(false),
                                    "aria-label": "Close panel",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_icons__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                        className: "h-6 w-6"
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                                children: themes.map((t)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: "flex w-full capitalize cursor-pointer px-6 py-3 transition ease-in-out duration-150 text-primary leading-6 font-medium items-center hover:bg-accent-1",
                                            role: "link",
                                            onClick: ()=>{
                                                setTheme(t);
                                                setDisplay(false);
                                            },
                                            children: t
                                        })
                                    }, t))
                            })
                        ]
                    }) : null
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ThemeSwitcher);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5342:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ commerce)
});

// EXTERNAL MODULE: ../node_modules/.pnpm/zod@3.19.1/node_modules/zod/lib/index.mjs
var lib = __webpack_require__(5882);
// EXTERNAL MODULE: ../packages/commerce/dist/utils/errors.js
var errors = __webpack_require__(152);
;// CONCATENATED MODULE: ../packages/commerce/dist/api/utils/errors.js


class CommerceAPIResponseError extends Error {
    constructor(msg, res, data){
        super(msg);
        this.name = "CommerceApiError";
        this.status = res.status;
        this.res = res;
        this.data = data;
    }
}
class CommerceAPIError extends Error {
    constructor(msg, options){
        super(msg);
        this.name = "CommerceApiError";
        this.status = (options == null ? void 0 : options.status) || 500;
        this.code = (options == null ? void 0 : options.code) || "api_error";
    }
}
class CommerceNetworkError extends Error {
    constructor(msg){
        super(msg);
        this.name = "CommerceNetworkError";
    }
}
const normalizeZodIssues = (issues)=>issues.map(({ path , message  })=>path.length ? `${message} at "${path.join(".")}" field` : message);
const getOperationError = (operation, error)=>{
    if (error instanceof lib/* ZodError */.jm) {
        return new errors/* CommerceError */.yG({
            code: "SCHEMA_VALIDATION_ERROR",
            message: `Validation ${error.issues.length === 1 ? "error" : "errors"} at "${operation}" operation: \n` + normalizeZodIssues(error.issues).join("\n")
        });
    }
    return error;
};
const normalizeApiError = (error, req)=>{
    if (error instanceof CommerceAPIResponseError && error.res) {
        return error.res;
    }
    (req == null ? void 0 : req.url) && console.log(req.url);
    if (error instanceof ZodError) {
        const message = "Validation error, please check the input data!";
        const errors = normalizeZodIssues(error.issues).map((message)=>({
                message
            }));
        console.error(`${message}\n${errors.map((e)=>e.message).join("\n")}`);
        return {
            status: 400,
            data: null,
            errors
        };
    }
    console.error(error);
    if (error instanceof CommerceAPIError) {
        return {
            errors: [
                {
                    message: error.message,
                    code: error.code
                }, 
            ],
            status: error.status
        };
    }
    return {
        data: null,
        errors: [
            {
                message: "An unexpected error ocurred"
            }
        ]
    };
};

;// CONCATENATED MODULE: ../packages/commerce/dist/schemas/page.js

const pageSchema = lib.z.object({
    id: lib.z.string(),
    name: lib.z.string(),
    url: lib.z.string().startsWith("/").optional(),
    body: lib.z.string(),
    is_visible: lib.z.boolean().optional(),
    sort_order: lib.z.number().optional()
});
const pagesPathsSchema = lib.z.array(lib.z.object({
    page: lib.z.object({
        path: lib.z.string().startsWith("/")
    })
}));

;// CONCATENATED MODULE: ../packages/commerce/dist/schemas/site.js

const siteInfoSchema = lib.z.object({
    categories: lib.z.array(lib.z.object({
        id: lib.z.string(),
        name: lib.z.string(),
        path: lib.z.string().startsWith("/")
    })),
    brands: lib.z.array(lib.z.object({
        id: lib.z.string(),
        name: lib.z.string(),
        path: lib.z.string().startsWith("/")
    }))
});

;// CONCATENATED MODULE: ../packages/commerce/dist/schemas/product.js

const productPriceSchema = lib.z.object({
    value: lib.z.number(),
    currencyCode: lib.z.string().max(3).optional(),
    retailPrice: lib.z.number().optional()
});
const productOptionSchema = lib.z.object({
    id: lib.z.string(),
    displayName: lib.z.string(),
    values: lib.z.array(lib.z.object({
        label: lib.z.string(),
        hexColors: lib.z.array(lib.z.string()).optional()
    }))
});
const productImageSchema = lib.z.object({
    url: lib.z.string().url().or(lib.z.string().startsWith("/")),
    alt: lib.z.string().optional(),
    width: lib.z.number().optional(),
    height: lib.z.number().optional()
});
const productVariantSchema = lib.z.object({
    id: lib.z.string(),
    sku: lib.z.string().nullish(),
    name: lib.z.string().optional(),
    options: lib.z.array(productOptionSchema),
    image: productImageSchema.optional()
});
const productSchema = lib.z.object({
    id: lib.z.string(),
    name: lib.z.string(),
    description: lib.z.string(),
    descriptionHtml: lib.z.string().optional(),
    sku: lib.z.string().nullish(),
    slug: lib.z.string(),
    path: lib.z.string().startsWith("/"),
    images: lib.z.array(productImageSchema),
    variants: lib.z.array(productVariantSchema),
    price: productPriceSchema,
    options: lib.z.array(productOptionSchema),
    vendor: lib.z.string().optional()
});
const productsPathsSchema = lib.z.array(lib.z.object({
    path: lib.z.string().startsWith("/")
}));
const searchProductBodySchema = lib.z.object({
    search: lib.z.string().optional(),
    categoryId: lib.z.string().optional(),
    brandId: lib.z.string().optional(),
    sort: lib.z.string().optional(),
    locale: lib.z.string().optional()
});
const searchProductsSchema = lib.z.object({
    products: lib.z.array(productSchema),
    found: lib.z.boolean()
});

;// CONCATENATED MODULE: ../packages/commerce/dist/api/utils/with-operation-callback.js





const withOperationCallback = (name, fn)=>async (...args)=>{
        try {
            const data = await fn(...args);
            parse({
                name,
                data
            });
            return data;
        } catch (error) {
            throw getOperationError(name, error);
        }
    };
const parse = ({ name , data  })=>{
    switch(name){
        case "getProduct":
            productSchema.optional().parse(data.product);
            break;
        case "getAllProducts":
            lib.z.array(productSchema).parse(data.products);
            break;
        case "getAllProductPaths":
            productsPathsSchema.parse(data.products);
            break;
        case "getPage":
            pageSchema.nullable().parse(data.page);
            break;
        case "getAllPages":
            lib.z.array(pageSchema).parse(data.pages);
            break;
        case "getSiteInfo":
            siteInfoSchema.parse(data);
            break;
    }
};

;// CONCATENATED MODULE: ../packages/commerce/dist/api/operations.js
const noop = ()=>{
    throw new Error("Not implemented");
};
const OPERATIONS = [
    "login",
    "getAllPages",
    "getPage",
    "getSiteInfo",
    "getCustomerWishlist",
    "getAllProductPaths",
    "getAllProducts",
    "getProduct", 
];
const defaultOperations = OPERATIONS.reduce((ops, k)=>{
    ops[k] = noop;
    return ops;
}, {});

;// CONCATENATED MODULE: ../packages/commerce/dist/api/index.js


class CommerceAPICore {
    constructor(provider){
        this.provider = provider;
    }
    getConfig(userConfig = {}) {
        return Object.entries(userConfig).reduce((cfg, [key, value])=>Object.assign(cfg, {
                [key]: value
            }), {
            ...this.provider.config
        });
    }
    setConfig(newConfig) {
        Object.assign(this.provider.config, newConfig);
    }
}
function getCommerceApi(customProvider) {
    const commerce = Object.assign(new CommerceAPICore(customProvider), defaultOperations);
    const ops = customProvider.operations;
    OPERATIONS.forEach((k)=>{
        const op = ops[k];
        if (op) {
            commerce[k] = withOperationCallback(k, op({
                commerce
            }));
        }
    });
    return commerce;
}
function getEndpoint(commerce, context) {
    const cfg = commerce.getConfig(context.config);
    return function apiHandler(req) {
        return context.handler({
            req,
            commerce,
            config: cfg,
            handlers: context.handlers,
            options: context.options ?? {}
        });
    };
}
const createEndpoint = (endpoint)=>(commerce, context)=>{
        return getEndpoint(commerce, {
            ...endpoint,
            ...context
        });
    };

;// CONCATENATED MODULE: ../packages/local/dist/api/utils/fetch-local.js

const fetchGraphqlApi = (getConfig)=>async (query, { variables , preview  } = {}, headers)=>{
        const config = getConfig();
        const res = await fetch(config.commerceUrl, {
            method: "POST",
            headers: {
                ...headers,
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                query,
                variables
            })
        });
        const json = await res.json();
        if (json.errors) {
            throw new errors/* FetcherError */.T4({
                errors: json.errors ?? [
                    {
                        message: "Failed to fetch for API"
                    }
                ],
                status: res.status
            });
        }
        return {
            data: json.data,
            res
        };
    };
/* harmony default export */ const fetch_local = (fetchGraphqlApi);

;// CONCATENATED MODULE: ../packages/local/dist/api/operations/get-all-pages.js
function getAllPagesOperation() {
    function getAllPages({ config , preview  }) {
        return Promise.resolve({
            pages: []
        });
    }
    return getAllPages;
};

;// CONCATENATED MODULE: ../packages/local/dist/api/operations/get-page.js
function getPageOperation() {
    function getPage() {
        return Promise.resolve({});
    }
    return getPage;
};

;// CONCATENATED MODULE: ../packages/local/dist/api/operations/get-site-info.js
function getSiteInfoOperation({}) {
    function getSiteInfo({ query , variables , config: cfg  } = {}) {
        return Promise.resolve({
            categories: [
                {
                    id: "new-arrivals",
                    name: "New Arrivals",
                    slug: "new-arrivals",
                    path: "/new-arrivals"
                },
                {
                    id: "featured",
                    name: "Featured",
                    slug: "featured",
                    path: "/featured"
                }, 
            ],
            brands: []
        });
    }
    return getSiteInfo;
};

;// CONCATENATED MODULE: ../packages/local/dist/api/operations/get-customer-wishlist.js
function getCustomerWishlistOperation() {
    function getCustomerWishlist() {
        return {
            wishlist: {}
        };
    }
    return getCustomerWishlist;
};

;// CONCATENATED MODULE: ../packages/local/dist/data.json
const data_namespaceObject = JSON.parse('{"R":[{"id":"Z2lkOi8vc2hvcGlmeS9Qcm9kdWN0LzU0NDczMjUwMjQ0MjA=","name":"New Short Sleeve T-Shirt","vendor":"Next.js","path":"/new-short-sleeve-t-shirt","slug":"new-short-sleeve-t-shirt","price":{"value":25,"currencyCode":"USD"},"description":"Show off your love for Next.js and Vercel with this unique, limited edition t-shirt. This design is part of a limited run, numbered drop at the June 2021 Next.js Conf. It features a unique, handcrafted triangle design. Get it while supplies last - only 200 of these shirts will be made! All proceeds will be donated to charity.","descriptionHtml":"<p><span>Show off your love for Next.js and Vercel with this unique,&nbsp;</span><strong>limited edition</strong><span>&nbsp;t-shirt. This design is part of a limited run, numbered drop at the June 2021 Next.js Conf. It features a unique, handcrafted triangle design. Get it while supplies last - only 200 of these shirts will be made!&nbsp;</span><strong>All proceeds will be donated to charity.</strong></p>","images":[{"url":"/assets/drop-shirt-0.png","altText":"Shirt","width":1000,"height":1000},{"url":"/assets/drop-shirt-1.png","altText":"Shirt","width":1000,"height":1000},{"url":"/assets/drop-shirt-2.png","altText":"Shirt","width":1000,"height":1000}],"variants":[{"id":"Z2lkOi8vc2hvcGlmeS9Qcm9kdWN0LzU0NDczMjUwMjQ0MjAss=","name":"New Short Sleeve T-Shirt","sku":"new-short-sleeve-t-shirt","options":[{"__typename":"MultipleChoiceOption","id":"asd","displayName":"Size","values":[{"label":"XL"}]}]}],"options":[{"id":"option-color","displayName":"Color","values":[{"label":"color","hexColors":["#222"]}]},{"id":"option-size","displayName":"Size","values":[{"label":"S"},{"label":"M"},{"label":"L"}]}]},{"id":"Z2lkOi8vc2hvcGlmeS9Qcm9ksdWN0LzU0NDczMjUwMjQ0MjA=","name":"Lightweight Jacket","vendor":"Next.js","path":"/lightweight-jacket","slug":"lightweight-jacket","price":{"value":249.99,"currencyCode":"USD"},"description":"Show off your love for Next.js and Vercel with this unique, limited edition t-shirt. This design is part of a limited run, numbered drop at the June 2021 Next.js Conf. It features a unique, handcrafted triangle design. Get it while supplies last - only 200 of these shirts will be made! All proceeds will be donated to charity.","descriptionHtml":"<p><span>Show off your love for Next.js and Vercel with this unique,&nbsp;</span><strong>limited edition</strong><span>&nbsp;t-shirt. This design is part of a limited run, numbered drop at the June 2021 Next.js Conf. It features a unique, handcrafted triangle design. Get it while supplies last – only 200 of these shirts will be made!&nbsp;</span><strong>All proceeds will be donated to charity.</strong></p>","images":[{"url":"/assets/lightweight-jacket-0.png","altText":"Lightweight Jacket","width":1000,"height":1000},{"url":"/assets/lightweight-jacket-1.png","altText":"Lightweight Jacket","width":1000,"height":1000},{"url":"/assets/lightweight-jacket-2.png","altText":"Lightweight Jacket","width":1000,"height":1000}],"variants":[{"id":"Z2lkOid8vc2hvcGlmeS9Qcm9kdWN0LzU0NDczMjUwMjQ0MjAss=","name":"Lightweight Jacket","sku":"lightweight-jacket","options":[{"__typename":"MultipleChoiceOption","id":"asd","displayName":"Size","values":[{"label":"XL"}]}]}],"options":[{"id":"option-color","displayName":"Color","values":[{"label":"color","hexColors":["#222"]}]},{"id":"option-size","displayName":"Size","values":[{"label":"S"},{"label":"M"},{"label":"L"}]}]},{"id":"Z2lkOis8vc2hvcGlmsddeS9Qcm9kdWN0LzU0NDczMjUwMjQ0MjA=","name":"Shirt","vendor":"Next.js","path":"/shirt","slug":"shirt","price":{"value":25,"currencyCode":"USD"},"description":"Show off your love for Next.js and Vercel with this unique, limited edition t-shirt. This design is part of a limited run, numbered drop at the June 2021 Next.js Conf. It features a unique, handcrafted triangle design. Get it while supplies last - only 200 of these shirts will be made! All proceeds will be donated to charity.","descriptionHtml":"<p><span>Show off your love for Next.js and Vercel with this unique,&nbsp;</span><strong>limited edition</strong><span>&nbsp;t-shirt. This design is part of a limited run, numbered drop at the June 2021 Next.js Conf. It features a unique, handcrafted triangle design. Get it while supplies last – only 200 of these shirts will be made!&nbsp;</span><strong>All proceeds will be donated to charity.</strong></p>","images":[{"url":"/assets/t-shirt-0.png","altText":"Shirt","width":1000,"height":1000},{"url":"/assets/t-shirt-1.png","altText":"Shirt","width":1000,"height":1000},{"url":"/assets/t-shirt-2.png","altText":"Shirt","width":1000,"height":1000},{"url":"/assets/t-shirt-3.png","altText":"Shirt","width":1000,"height":1000},{"url":"/assets/t-shirt-4.png","altText":"Shirt","width":1000,"height":1000}],"variants":[{"id":"Z2lkOi8vc2hvcGlmeS9Qcms9kdWN0LzU0NDczMjUwMjQ0MjAss=","name":"Shirt","sku":"shirt","options":[{"__typename":"MultipleChoiceOption","id":"asd","displayName":"Size","values":[{"label":"XL"}]}]}],"options":[{"id":"option-color","displayName":"Color","values":[{"label":"color","hexColors":["#222"]}]},{"id":"option-size","displayName":"Size","values":[{"label":"S"},{"label":"M"},{"label":"L"}]}]}]}');
;// CONCATENATED MODULE: ../packages/local/dist/api/operations/get-all-product-paths.js

function getAllProductPathsOperation() {
    function getAllProductPaths() {
        return Promise.resolve({
            products: data_namespaceObject.R.map(({ path  })=>({
                    path
                }))
        });
    }
    return getAllProductPaths;
};

;// CONCATENATED MODULE: ../packages/local/dist/api/operations/get-all-products.js

function getAllProductsOperation({ commerce  }) {
    async function getAllProducts({ query ="" , variables , config  } = {}) {
        return {
            products: data_namespaceObject.R
        };
    }
    return getAllProducts;
};

;// CONCATENATED MODULE: ../packages/local/dist/api/operations/get-product.js

function getProductOperation(_p) {
    async function getProduct({ query ="" , variables , config  } = {}) {
        return {
            product: data_namespaceObject.R.find(({ slug  })=>slug === variables.slug)
        };
    }
    return getProduct;
};

;// CONCATENATED MODULE: ../packages/local/dist/api/index.js









const config = {
    commerceUrl: "",
    apiToken: "",
    cartCookie: "",
    customerCookie: "",
    cartCookieMaxAge: 2592000,
    fetch: fetch_local(()=>api_getCommerceApi().getConfig())
};
const operations = {
    getAllPages: getAllPagesOperation,
    getPage: getPageOperation,
    getSiteInfo: getSiteInfoOperation,
    getCustomerWishlist: getCustomerWishlistOperation,
    getAllProductPaths: getAllProductPathsOperation,
    getAllProducts: getAllProductsOperation,
    getProduct: getProductOperation
};
const provider = {
    config,
    operations
};
function api_getCommerceApi(customProvider = provider) {
    return getCommerceApi(customProvider);
}

;// CONCATENATED MODULE: ./lib/api/commerce.ts

/* harmony default export */ const commerce = (api_getCommerceApi());


/***/ }),

/***/ 3458:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_merge_refs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8230);
/* harmony import */ var _has_parent__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8779);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_merge_refs__WEBPACK_IMPORTED_MODULE_1__]);
react_merge_refs__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



/**
 * Use forward ref to allow this component to be used with other components like
 * focus-trap-react, that rely on the same type of ref forwarding to direct children
 */ const ClickOutside = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_0__.forwardRef)(({ active =true , onClick , children  }, forwardedRef)=>{
    const innerRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();
    const child = children ? react__WEBPACK_IMPORTED_MODULE_0___default().Children.only(children) : undefined;
    if (!child || child.type === (react__WEBPACK_IMPORTED_MODULE_0___default().Fragment)) {
        /**
       * React Fragments can't be used, as it would not be possible to pass the ref
       * created here to them.
       */ throw new Error("A valid non Fragment React Children should be provided");
    }
    if (typeof onClick != "function") {
        throw new Error("onClick must be a valid function");
    }
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (active) {
            document.addEventListener("mousedown", handleClick);
            document.addEventListener("touchstart", handleClick);
        }
        return ()=>{
            if (active) {
                document.removeEventListener("mousedown", handleClick);
                document.removeEventListener("touchstart", handleClick);
            }
        };
    });
    const handleClick = (event)=>{
        /**
       * Check if the clicked element is contained by the top level tag provided to the
       * ClickOutside component, if not, Outside clicked! Fire onClick cb
       */ if (!(0,_has_parent__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(event.target, innerRef?.current)) {
            onClick(event);
        }
    };
    /**
     * Preserve the child ref prop if exists and merge it with the one used here and the
     * proxied by the forwardRef method
     */ const composedRefCallback = (element)=>{
        if (typeof child.ref === "function") {
            child.ref(element);
        } else if (child.ref) {
            child.ref.current = element;
        }
    };
    return /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_0___default().cloneElement(child, {
        ref: (0,react_merge_refs__WEBPACK_IMPORTED_MODULE_1__.mergeRefs)([
            composedRefCallback,
            innerRef,
            forwardedRef
        ])
    });
});
ClickOutside.displayName = "ClickOutside";
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ClickOutside);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8779:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ hasParent)
});

;// CONCATENATED MODULE: ./lib/click-outside/is-in-dom.js
function isInDom(obj) {
    return Boolean(obj.closest("body"));
}

;// CONCATENATED MODULE: ./lib/click-outside/has-parent.js

function hasParent(element, root) {
    return root && root.contains(element) && isInDom(element);
}


/***/ }),

/***/ 6550:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_T": () => (/* binding */ isDark),
/* harmony export */   "uo": () => (/* binding */ getRandomPairOfColors)
/* harmony export */ });
/* unused harmony export colorMap */
/* harmony import */ var lodash_random__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3746);
/* harmony import */ var lodash_random__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash_random__WEBPACK_IMPORTED_MODULE_0__);

function getRandomPairOfColors() {
    const colors = [
        "#37B679",
        "#DA3C3C",
        "#3291FF",
        "#7928CA",
        "#79FFE1"
    ];
    const getRandomIdx = ()=>lodash_random__WEBPACK_IMPORTED_MODULE_0___default()(0, colors.length - 1);
    let idx = getRandomIdx();
    let idx2 = getRandomIdx();
    // Has to be a different color
    while(idx2 === idx){
        idx2 = getRandomIdx();
    }
    // Returns a pair of colors
    return [
        colors[idx],
        colors[idx2]
    ];
}
function hexToRgb(hex = "") {
    // @ts-ignore
    const match = hex.toString(16).match(/[a-f0-9]{6}|[a-f0-9]{3}/i);
    if (!match) {
        return [
            0,
            0,
            0
        ];
    }
    let colorString = match[0];
    if (match[0].length === 3) {
        colorString = colorString.split("").map((char)=>{
            return char + char;
        }).join("");
    }
    const integer = parseInt(colorString, 16);
    const r = integer >> 16 & 0xff;
    const g = integer >> 8 & 0xff;
    const b = integer & 0xff;
    return [
        r,
        g,
        b
    ];
}
const colorMap = {
    aliceblue: "#F0F8FF",
    antiquewhite: "#FAEBD7",
    aqua: "#00FFFF",
    aquamarine: "#7FFFD4",
    azure: "#F0FFFF",
    beige: "#F5F5DC",
    bisque: "#FFE4C4",
    black: "#000000",
    blanchedalmond: "#FFEBCD",
    blue: "#0000FF",
    blueviolet: "#8A2BE2",
    brown: "#A52A2A",
    burlywood: "#DEB887",
    burgandy: "#800020",
    burgundy: "#800020",
    cadetblue: "#5F9EA0",
    chartreuse: "#7FFF00",
    chocolate: "#D2691E",
    coral: "#FF7F50",
    cornflowerblue: "#6495ED",
    cornsilk: "#FFF8DC",
    crimson: "#DC143C",
    cyan: "#00FFFF",
    darkblue: "#00008B",
    darkcyan: "#008B8B",
    darkgoldenrod: "#B8860B",
    darkgray: "#A9A9A9",
    darkgreen: "#006400",
    darkgrey: "#A9A9A9",
    darkkhaki: "#BDB76B",
    darkmagenta: "#8B008B",
    darkolivegreen: "#556B2F",
    darkorange: "#FF8C00",
    darkorchid: "#9932CC",
    darkred: "#8B0000",
    darksalmon: "#E9967A",
    darkseagreen: "#8FBC8F",
    darkslateblue: "#483D8B",
    darkslategray: "#2F4F4F",
    darkslategrey: "#2F4F4F",
    darkturquoise: "#00CED1",
    darkviolet: "#9400D3",
    deeppink: "#FF1493",
    deepskyblue: "#00BFFF",
    dimgray: "#696969",
    dimgrey: "#696969",
    dodgerblue: "#1E90FF",
    firebrick: "#B22222",
    floralwhite: "#FFFAF0",
    forestgreen: "#228B22",
    fuchsia: "#FF00FF",
    gainsboro: "#DCDCDC",
    ghostwhite: "#F8F8FF",
    gold: "#FFD700",
    goldenrod: "#DAA520",
    gray: "#808080",
    green: "#008000",
    greenyellow: "#ADFF2F",
    grey: "#808080",
    honeydew: "#F0FFF0",
    hotpink: "#FF69B4",
    indianred: "#CD5C5C",
    indigo: "#4B0082",
    ivory: "#FFFFF0",
    khaki: "#F0E68C",
    lavender: "#E6E6FA",
    lavenderblush: "#FFF0F5",
    lawngreen: "#7CFC00",
    lemonchiffon: "#FFFACD",
    lightblue: "#ADD8E6",
    lightcoral: "#F08080",
    lightcyan: "#E0FFFF",
    lightgoldenrodyellow: "#FAFAD2",
    lightgray: "#D3D3D3",
    lightgreen: "#90EE90",
    lightgrey: "#D3D3D3",
    lightpink: "#FFB6C1",
    lightsalmon: "#FFA07A",
    lightseagreen: "#20B2AA",
    lightskyblue: "#87CEFA",
    lightslategray: "#778899",
    lightslategrey: "#778899",
    lightsteelblue: "#B0C4DE",
    lightyellow: "#FFFFE0",
    lime: "#00FF00",
    limegreen: "#32CD32",
    linen: "#FAF0E6",
    magenta: "#FF00FF",
    maroon: "#800000",
    mediumaquamarine: "#66CDAA",
    mediumblue: "#0000CD",
    mediumorchid: "#BA55D3",
    mediumpurple: "#9370DB",
    mediumseagreen: "#3CB371",
    mediumslateblue: "#7B68EE",
    mediumspringgreen: "#00FA9A",
    mediumturquoise: "#48D1CC",
    mediumvioletred: "#C71585",
    midnightblue: "#191970",
    mintcream: "#F5FFFA",
    mistyrose: "#FFE4E1",
    moccasin: "#FFE4B5",
    navajowhite: "#FFDEAD",
    navy: "#000080",
    oldlace: "#FDF5E6",
    olive: "#808000",
    olivedrab: "#6B8E23",
    orange: "#FFA500",
    orangered: "#FF4500",
    orchid: "#DA70D6",
    palegoldenrod: "#EEE8AA",
    palegreen: "#98FB98",
    paleturquoise: "#AFEEEE",
    palevioletred: "#DB7093",
    papayawhip: "#FFEFD5",
    peachpuff: "#FFDAB9",
    peru: "#CD853F",
    pink: "#FFC0CB",
    plum: "#DDA0DD",
    powderblue: "#B0E0E6",
    purple: "#800080",
    rebeccapurple: "#663399",
    red: "#FF0000",
    rosybrown: "#BC8F8F",
    royalblue: "#4169E1",
    saddlebrown: "#8B4513",
    salmon: "#FA8072",
    sandybrown: "#F4A460",
    seagreen: "#2E8B57",
    seashell: "#FFF5EE",
    sienna: "#A0522D",
    silver: "#C0C0C0",
    skyblue: "#87CEEB",
    slateblue: "#6A5ACD",
    slategray: "#708090",
    slategrey: "#708090",
    spacegrey: "#65737e",
    spacegray: "#65737e",
    snow: "#FFFAFA",
    springgreen: "#00FF7F",
    steelblue: "#4682B4",
    tan: "#D2B48C",
    teal: "#008080",
    thistle: "#D8BFD8",
    tomato: "#FF6347",
    turquoise: "#40E0D0",
    violet: "#EE82EE",
    wheat: "#F5DEB3",
    white: "#FFFFFF",
    whitesmoke: "#F5F5F5",
    yellow: "#FFFF00",
    yellowgreen: "#9ACD32"
};
function isDark(color = "") {
    color = color.toLowerCase();
    // Equation from http://24ways.org/2010/calculating-color-contrast
    let rgb = colorMap[color] ? hexToRgb(colorMap[color]) : hexToRgb(color);
    const res = (rgb[0] * 299 + rgb[1] * 587 + rgb[2] * 114) / 1000;
    return res < 128;
}


/***/ }),

/***/ 7240:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// Remove trailing and leading slash, usually included in nodes
// returned by the BigCommerce API
const getSlug = (path)=>path.replace(/^\/|\/$/g, "");
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (getSlug);


/***/ }),

/***/ 2041:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ useAcceptCookies)
/* harmony export */ });
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9915);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_0__]);
js_cookie__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const COOKIE_NAME = "accept_cookies";
const useAcceptCookies = ()=>{
    const [acceptedCookies, setAcceptedCookies] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].get(COOKIE_NAME)) {
            setAcceptedCookies(false);
        }
    }, []);
    const acceptCookies = ()=>{
        setAcceptedCookies(true);
        js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].set(COOKIE_NAME, "accepted", {
            expires: 365
        });
    };
    return {
        acceptedCookies,
        onAcceptCookies: acceptCookies
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6422:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ useToggleTheme)
/* harmony export */ });
/* harmony import */ var next_themes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1162);
/* harmony import */ var next_themes__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_themes__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const useToggleTheme = ()=>{
    const { theme , themes , setTheme  } = (0,next_themes__WEBPACK_IMPORTED_MODULE_0__.useTheme)();
    const [themeValue, setThemeValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("system");
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>setThemeValue(theme), [
        theme
    ]);
    return {
        theme: themeValue,
        setTheme,
        themes
    };
};


/***/ }),

/***/ 9845:
/***/ ((__webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(__webpack_module__, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export fetcher */
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9915);
/* harmony import */ var _utils_use_hook__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7227);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9521);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_0__]);
js_cookie__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const fetcher = async ({ options , input: { cartId  } , fetch ,  })=>{
    return cartId ? await fetch(options) : null;
};
const fn = (provider)=>{
    var ref;
    return (ref = provider.cart) == null ? void 0 : ref.useCart;
};
const useCart = (input)=>{
    const hook = (0,_utils_use_hook__WEBPACK_IMPORTED_MODULE_1__/* .useHook */ .dV)(fn);
    const { cartCookie  } = (0,___WEBPACK_IMPORTED_MODULE_2__/* .useCommerce */ .aF)();
    const fetcherFn = hook.fetcher ?? fetcher;
    const wrapper = (context)=>{
        context.input.cartId = js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].get(cartCookie);
        return fetcherFn(context);
    };
    return (0,_utils_use_hook__WEBPACK_IMPORTED_MODULE_1__/* .useSWRHook */ .Lz)({
        ...hook,
        fetcher: wrapper
    })(input);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useCart);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9500:
/***/ ((__webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(__webpack_module__, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export fetcher */
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9915);
/* harmony import */ var _utils_use_hook__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7227);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9521);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_0__]);
js_cookie__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const fetcher = async ({ options , input: { cartId  } , fetch ,  })=>{
    return cartId ? await fetch(options) : null;
};
const fn = (provider)=>{
    var ref;
    return (ref = provider.checkout) == null ? void 0 : ref.useCheckout;
};
const useCheckout = (input)=>{
    const hook = (0,_utils_use_hook__WEBPACK_IMPORTED_MODULE_1__/* .useHook */ .dV)(fn);
    const { cartCookie  } = (0,___WEBPACK_IMPORTED_MODULE_2__/* .useCommerce */ .aF)();
    const fetcherFn = hook.fetcher ?? fetcher;
    const wrapper = (context)=>{
        context.input.cartId = js_cookie__WEBPACK_IMPORTED_MODULE_0__["default"].get(cartCookie);
        return fetcherFn(context);
    };
    return (0,_utils_use_hook__WEBPACK_IMPORTED_MODULE_1__/* .useSWRHook */ .Lz)({
        ...hook,
        fetcher: wrapper
    })(input);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useCheckout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9521:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DX": () => (/* binding */ getCommerceProvider),
/* harmony export */   "aF": () => (/* binding */ useCommerce)
/* harmony export */ });
/* unused harmony export CoreCommerceProvider */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);


const Commerce = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({});
function CoreCommerceProvider({ provider , children  }) {
    const providerRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(provider);
    // TODO: Remove the fetcherRef
    const fetcherRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(provider.fetcher);
    // If the parent re-renders this provider will re-render every
    // consumer unless we memoize the config
    const { locale , cartCookie  } = providerRef.current;
    const cfg = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>({
            providerRef,
            fetcherRef,
            locale,
            cartCookie
        }), [
        locale,
        cartCookie
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Commerce.Provider, {
        value: cfg,
        children: children
    });
}
function getCommerceProvider(provider) {
    return function CommerceProvider({ children , ...props }) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CoreCommerceProvider, {
            provider: {
                ...provider,
                ...props
            },
            children: children
        });
    };
}
function useCommerce() {
    return (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(Commerce);
}


/***/ }),

/***/ 4398:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (/* binding */ usePrice)
/* harmony export */ });
/* unused harmony exports formatPrice, formatVariantPrice */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9521);


function formatPrice({ amount , currencyCode , locale  }) {
    const formatCurrency = new Intl.NumberFormat(locale, {
        style: "currency",
        currency: currencyCode
    });
    return formatCurrency.format(amount);
}
function formatVariantPrice({ amount , baseAmount , currencyCode , locale  }) {
    const hasDiscount = baseAmount > amount;
    const formatDiscount = new Intl.NumberFormat(locale, {
        style: "percent"
    });
    const discount = hasDiscount ? formatDiscount.format((baseAmount - amount) / baseAmount) : null;
    const price = formatPrice({
        amount,
        currencyCode,
        locale
    });
    const basePrice = hasDiscount ? formatPrice({
        amount: baseAmount,
        currencyCode,
        locale
    }) : null;
    return {
        price,
        basePrice,
        discount
    };
}
function usePrice(data) {
    const { amount , baseAmount , currencyCode  } = data ?? {};
    const { locale  } = (0,___WEBPACK_IMPORTED_MODULE_1__/* .useCommerce */ .aF)();
    const value = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>{
        if (typeof amount !== "number" || !currencyCode) return "";
        return baseAmount ? formatVariantPrice({
            amount,
            baseAmount,
            currencyCode,
            locale
        }) : formatPrice({
            amount,
            currencyCode,
            locale
        });
    }, [
        amount,
        baseAmount,
        currencyCode
    ]);
    return typeof value === "string" ? {
        price: value
    } : value;
};


/***/ }),

/***/ 663:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B5": () => (/* binding */ mutationFetcher),
/* harmony export */   "DO": () => (/* binding */ SWRFetcher)
/* harmony export */ });
const SWRFetcher = ({ options , fetch  })=>fetch(options);
const mutationFetcher = ({ input , options , fetch ,  })=>fetch({
        ...options,
        body: input
    });
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (SWRFetcher)));


/***/ }),

/***/ 152:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T4": () => (/* binding */ FetcherError),
/* harmony export */   "yG": () => (/* binding */ CommerceError)
/* harmony export */ });
/* unused harmony export ValidationError */
class CommerceError extends Error {
    constructor({ message , code , errors  }){
        const error = message ? {
            message,
            ...code ? {
                code
            } : {}
        } : errors[0];
        super(error.message);
        this.errors = message ? [
            error
        ] : errors;
        if (error.code) this.code = error.code;
    }
}
// Used for errors that come from a bad implementation of the hooks
class ValidationError extends (/* unused pure expression or super */ null && (CommerceError)) {
    constructor(options){
        super(options);
        this.code = "validation_error";
    }
}
class FetcherError extends CommerceError {
    constructor(options){
        super(options);
        this.status = options.status;
    }
}


/***/ }),

/***/ 7227:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "dV": () => (/* binding */ useHook),
  "wf": () => (/* binding */ useMutationHook),
  "Lz": () => (/* binding */ useSWRHook)
});

// UNUSED EXPORTS: useFetcher

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ../packages/commerce/dist/index.js
var dist = __webpack_require__(9521);
// EXTERNAL MODULE: ../node_modules/.pnpm/swr@1.3.0_react@18.2.0/node_modules/swr/dist/index.mjs
var swr_dist = __webpack_require__(2976);
;// CONCATENATED MODULE: ../packages/commerce/dist/utils/define-property.js
// Taken from https://fettblog.eu/typescript-assertion-signatures/
function defineProperty(obj, prop, val) {
    Object.defineProperty(obj, prop, val);
};

// EXTERNAL MODULE: ../packages/commerce/dist/utils/errors.js
var errors = __webpack_require__(152);
;// CONCATENATED MODULE: ../packages/commerce/dist/utils/use-data.js



const useData = (options, input, fetcherFn, swrOptions)=>{
    const hookInput = Array.isArray(input) ? input : Object.entries(input);
    const fetcher = async (url, query, method, ...args)=>{
        try {
            return await options.fetcher({
                options: {
                    url,
                    query,
                    method
                },
                // Transform the input array into an object
                input: args.reduce((obj, val, i)=>{
                    obj[hookInput[i][0]] = val;
                    return obj;
                }, {}),
                fetch: fetcherFn
            });
        } catch (error) {
            // SWR will not log errors, but any error that's not an instance
            // of CommerceError is not welcomed by this hook
            if (!(error instanceof errors/* CommerceError */.yG)) {
                console.error(error);
            }
            throw error;
        }
    };
    const response = (0,swr_dist/* default */.ZP)(()=>{
        const opts = options.fetchOptions;
        return opts ? [
            opts.url,
            opts.query,
            opts.method,
            ...hookInput.map((e)=>e[1])
        ] : null;
    }, fetcher, swrOptions);
    if (!("isLoading" in response)) {
        defineProperty(response, "isLoading", {
            get () {
                return response.data === undefined;
            },
            enumerable: true
        });
    }
    return response;
};
/* harmony default export */ const use_data = (useData);

;// CONCATENATED MODULE: ../packages/commerce/dist/utils/use-hook.js



function useFetcher() {
    const { providerRef , fetcherRef  } = (0,dist/* useCommerce */.aF)();
    return providerRef.current.fetcher ?? fetcherRef.current;
}
function useHook(fn) {
    const { providerRef  } = (0,dist/* useCommerce */.aF)();
    const provider = providerRef.current;
    return fn(provider);
}
function useSWRHook(hook) {
    const fetcher = useFetcher();
    return hook.useHook({
        useData (ctx) {
            const response = use_data(hook, (ctx == null ? void 0 : ctx.input) ?? [], fetcher, ctx == null ? void 0 : ctx.swrOptions);
            return response;
        }
    });
}
function useMutationHook(hook) {
    const fetcher = useFetcher();
    return hook.useHook({
        fetch: (0,external_react_.useCallback)(({ input  } = {})=>{
            return hook.fetcher({
                input,
                options: hook.fetchOptions,
                fetch: fetcher
            });
        }, [
            fetcher,
            hook.fetchOptions
        ])
    });
}


/***/ }),

/***/ 2428:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ auth_use_login),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ../packages/commerce/dist/utils/use-hook.js + 2 modules
var use_hook = __webpack_require__(7227);
// EXTERNAL MODULE: ../packages/commerce/dist/utils/default-fetcher.js
var default_fetcher = __webpack_require__(663);
;// CONCATENATED MODULE: ../packages/commerce/dist/auth/use-login.js


const fetcher = default_fetcher/* mutationFetcher */.B5;
const fn = (provider)=>{
    var ref;
    return (ref = provider.auth) == null ? void 0 : ref.useLogin;
};
const useLogin = (...args)=>{
    const hook = (0,use_hook/* useHook */.dV)(fn);
    return (0,use_hook/* useMutationHook */.wf)({
        fetcher,
        ...hook
    })(...args);
};
/* harmony default export */ const use_login = (useLogin);

;// CONCATENATED MODULE: ../packages/local/dist/auth/use-login.js

/* harmony default export */ const auth_use_login = (use_login);
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher () {
        return null;
    },
    useHook: ()=>()=>{
            return async function() {};
        }
};


/***/ }),

/***/ 6667:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ auth_use_logout),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ../packages/commerce/dist/utils/use-hook.js + 2 modules
var use_hook = __webpack_require__(7227);
// EXTERNAL MODULE: ../packages/commerce/dist/utils/default-fetcher.js
var default_fetcher = __webpack_require__(663);
;// CONCATENATED MODULE: ../packages/commerce/dist/auth/use-logout.js


const fetcher = default_fetcher/* mutationFetcher */.B5;
const fn = (provider)=>{
    var ref;
    return (ref = provider.auth) == null ? void 0 : ref.useLogout;
};
const useLogout = (...args)=>{
    const hook = (0,use_hook/* useHook */.dV)(fn);
    return (0,use_hook/* useMutationHook */.wf)({
        fetcher,
        ...hook
    })(...args);
};
/* harmony default export */ const use_logout = (useLogout);

;// CONCATENATED MODULE: ../packages/local/dist/auth/use-logout.js

/* harmony default export */ const auth_use_logout = (use_logout);
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher () {
        return null;
    },
    useHook: ({ fetch  })=>()=>async ()=>{}
};


/***/ }),

/***/ 9557:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ auth_use_signup),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ../packages/commerce/dist/utils/use-hook.js + 2 modules
var use_hook = __webpack_require__(7227);
// EXTERNAL MODULE: ../packages/commerce/dist/utils/default-fetcher.js
var default_fetcher = __webpack_require__(663);
;// CONCATENATED MODULE: ../packages/commerce/dist/auth/use-signup.js


const fetcher = default_fetcher/* mutationFetcher */.B5;
const fn = (provider)=>{
    var ref;
    return (ref = provider.auth) == null ? void 0 : ref.useSignup;
};
const useSignup = (...args)=>{
    const hook = (0,use_hook/* useHook */.dV)(fn);
    return (0,use_hook/* useMutationHook */.wf)({
        fetcher,
        ...hook
    })(...args);
};
/* harmony default export */ const use_signup = (useSignup);

;// CONCATENATED MODULE: ../packages/local/dist/auth/use-signup.js

/* harmony default export */ const auth_use_signup = (use_signup);
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher () {
        return null;
    },
    useHook: ({ fetch  })=>()=>()=>{}
};


/***/ }),

/***/ 9957:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ cart_use_add_item),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ../packages/commerce/dist/utils/use-hook.js + 2 modules
var use_hook = __webpack_require__(7227);
// EXTERNAL MODULE: ../packages/commerce/dist/utils/default-fetcher.js
var default_fetcher = __webpack_require__(663);
;// CONCATENATED MODULE: ../packages/commerce/dist/cart/use-add-item.js


const fetcher = default_fetcher/* mutationFetcher */.B5;
const fn = (provider)=>{
    var ref;
    return (ref = provider.cart) == null ? void 0 : ref.useAddItem;
};
const useAddItem = (...args)=>{
    const hook = (0,use_hook/* useHook */.dV)(fn);
    return (0,use_hook/* useMutationHook */.wf)({
        fetcher,
        ...hook
    })(...args);
};
/* harmony default export */ const use_add_item = (useAddItem);

;// CONCATENATED MODULE: ../packages/local/dist/cart/use-add-item.js

/* harmony default export */ const cart_use_add_item = (use_add_item);
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher ({ input , options , fetch  }) {},
    useHook: ({ fetch  })=>()=>{
            return async function addItem() {
                return {};
            };
        }
};


/***/ }),

/***/ 6973:
/***/ ((__webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(__webpack_module__, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "y": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var _vercel_commerce_cart_use_cart__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9845);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_vercel_commerce_cart_use_cart__WEBPACK_IMPORTED_MODULE_1__]);
_vercel_commerce_cart_use_cart__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_vercel_commerce_cart_use_cart__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z);
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher () {
        return {
            id: "",
            createdAt: "",
            currency: {
                code: ""
            },
            taxesIncluded: "",
            lineItems: [],
            lineItemsSubtotalPrice: "",
            subtotalPrice: 0,
            totalPrice: 0
        };
    },
    useHook: ({ useData  })=>(input)=>{
            return (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(()=>Object.create({}, {
                    isEmpty: {
                        get () {
                            return true;
                        },
                        enumerable: true
                    }
                }), []);
        }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7260:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ cart_use_remove_item),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ../packages/commerce/dist/utils/use-hook.js + 2 modules
var use_hook = __webpack_require__(7227);
// EXTERNAL MODULE: ../packages/commerce/dist/utils/default-fetcher.js
var default_fetcher = __webpack_require__(663);
;// CONCATENATED MODULE: ../packages/commerce/dist/cart/use-remove-item.js


const fetcher = default_fetcher/* mutationFetcher */.B5;
const fn = (provider)=>{
    var ref;
    return (ref = provider.cart) == null ? void 0 : ref.useRemoveItem;
};
const useRemoveItem = (input)=>{
    const hook = (0,use_hook/* useHook */.dV)(fn);
    return (0,use_hook/* useMutationHook */.wf)({
        fetcher,
        ...hook
    })(input);
};
/* harmony default export */ const use_remove_item = (useRemoveItem);

;// CONCATENATED MODULE: ../packages/local/dist/cart/use-remove-item.js

/* harmony default export */ const cart_use_remove_item = (use_remove_item);
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher ({ input , options , fetch  }) {},
    useHook: ({ fetch  })=>()=>{
            return async function removeItem(input) {
                return {};
            };
        }
};


/***/ }),

/***/ 6789:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ cart_use_update_item),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ../packages/commerce/dist/utils/use-hook.js + 2 modules
var use_hook = __webpack_require__(7227);
// EXTERNAL MODULE: ../packages/commerce/dist/utils/default-fetcher.js
var default_fetcher = __webpack_require__(663);
;// CONCATENATED MODULE: ../packages/commerce/dist/cart/use-update-item.js


const fetcher = default_fetcher/* mutationFetcher */.B5;
const fn = (provider)=>{
    var ref;
    return (ref = provider.cart) == null ? void 0 : ref.useUpdateItem;
};
const useUpdateItem = (input)=>{
    const hook = (0,use_hook/* useHook */.dV)(fn);
    return (0,use_hook/* useMutationHook */.wf)({
        fetcher,
        ...hook
    })(input);
};
/* harmony default export */ const use_update_item = (useUpdateItem);

;// CONCATENATED MODULE: ../packages/local/dist/cart/use-update-item.js

/* harmony default export */ const cart_use_update_item = (use_update_item);
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher ({ input , options , fetch  }) {},
    useHook: ({ fetch  })=>()=>{
            return async function addItem() {
                return {};
            };
        }
};


/***/ }),

/***/ 2020:
/***/ ((__webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(__webpack_module__, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export handler */
/* harmony import */ var _vercel_commerce_checkout_use_checkout__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9500);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_vercel_commerce_checkout_use_checkout__WEBPACK_IMPORTED_MODULE_0__]);
_vercel_commerce_checkout_use_checkout__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_vercel_commerce_checkout_use_checkout__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z);
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher ({ input , options , fetch  }) {},
    useHook: ({ useData  })=>async (input)=>({})
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8056:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ address_use_add_item)
});

// UNUSED EXPORTS: handler

// EXTERNAL MODULE: ../packages/commerce/dist/utils/use-hook.js + 2 modules
var use_hook = __webpack_require__(7227);
// EXTERNAL MODULE: ../packages/commerce/dist/utils/default-fetcher.js
var default_fetcher = __webpack_require__(663);
;// CONCATENATED MODULE: ../packages/commerce/dist/customer/address/use-add-item.js


const fetcher = default_fetcher/* mutationFetcher */.B5;
const fn = (provider)=>{
    var ref, ref1;
    return (ref = provider.customer) == null ? void 0 : (ref1 = ref.address) == null ? void 0 : ref1.useAddItem;
};
const useAddItem = (...args)=>{
    const hook = (0,use_hook/* useHook */.dV)(fn);
    return (0,use_hook/* useMutationHook */.wf)({
        fetcher,
        ...hook
    })(...args);
};
/* harmony default export */ const use_add_item = (useAddItem);

;// CONCATENATED MODULE: ../packages/local/dist/customer/address/use-add-item.js

/* harmony default export */ const address_use_add_item = (use_add_item);
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher ({ input , options , fetch  }) {},
    useHook: ({ fetch  })=>()=>async ()=>({})
};


/***/ }),

/***/ 7754:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ card_use_add_item)
});

// UNUSED EXPORTS: handler

// EXTERNAL MODULE: ../packages/commerce/dist/utils/use-hook.js + 2 modules
var use_hook = __webpack_require__(7227);
// EXTERNAL MODULE: ../packages/commerce/dist/utils/default-fetcher.js
var default_fetcher = __webpack_require__(663);
;// CONCATENATED MODULE: ../packages/commerce/dist/customer/card/use-add-item.js


const fetcher = default_fetcher/* mutationFetcher */.B5;
const fn = (provider)=>{
    var ref, ref1;
    return (ref = provider.customer) == null ? void 0 : (ref1 = ref.card) == null ? void 0 : ref1.useAddItem;
};
const useAddItem = (...args)=>{
    const hook = (0,use_hook/* useHook */.dV)(fn);
    return (0,use_hook/* useMutationHook */.wf)({
        fetcher,
        ...hook
    })(...args);
};
/* harmony default export */ const use_add_item = (useAddItem);

;// CONCATENATED MODULE: ../packages/local/dist/customer/card/use-add-item.js

/* harmony default export */ const card_use_add_item = (use_add_item);
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher ({ input , options , fetch  }) {},
    useHook: ({ fetch  })=>()=>async ()=>({})
};


/***/ }),

/***/ 6999:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ customer_use_customer),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ../packages/commerce/dist/utils/use-hook.js + 2 modules
var use_hook = __webpack_require__(7227);
// EXTERNAL MODULE: ../packages/commerce/dist/utils/default-fetcher.js
var default_fetcher = __webpack_require__(663);
;// CONCATENATED MODULE: ../packages/commerce/dist/customer/use-customer.js


const fetcher = default_fetcher/* SWRFetcher */.DO;
const fn = (provider)=>{
    var ref;
    return (ref = provider.customer) == null ? void 0 : ref.useCustomer;
};
const useCustomer = (input)=>{
    const hook = (0,use_hook/* useHook */.dV)(fn);
    return (0,use_hook/* useSWRHook */.Lz)({
        fetcher,
        ...hook
    })(input);
};
/* harmony default export */ const use_customer = (useCustomer);

;// CONCATENATED MODULE: ../packages/local/dist/customer/use-customer.js

/* harmony default export */ const customer_use_customer = (use_customer);
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher ({ input , options , fetch  }) {},
    useHook: ()=>()=>{
            return async function addItem() {
                return {};
            };
        }
};


/***/ }),

/***/ 622:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ fetcher)
/* harmony export */ });
const fetcher = async ()=>{
    console.log("FETCHER");
    const res = await fetch("./data.json");
    if (res.ok) {
        const { data  } = await res.json();
        return data;
    }
    throw res;
};


/***/ }),

/***/ 1933:
/***/ ((__webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(__webpack_module__, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SN": () => (/* binding */ CommerceProvider)
/* harmony export */ });
/* unused harmony export useCommerce */
/* harmony import */ var _vercel_commerce__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9521);
/* harmony import */ var _provider__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8871);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_provider__WEBPACK_IMPORTED_MODULE_1__]);
_provider__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const CommerceProvider = (0,_vercel_commerce__WEBPACK_IMPORTED_MODULE_0__/* .getCommerceProvider */ .DX)(_provider__WEBPACK_IMPORTED_MODULE_1__/* .localProvider */ .W);
const useCommerce = ()=>useCoreCommerce();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4262:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ product_use_search),
  "y": () => (/* binding */ handler)
});

// EXTERNAL MODULE: ../packages/commerce/dist/utils/use-hook.js + 2 modules
var use_hook = __webpack_require__(7227);
// EXTERNAL MODULE: ../packages/commerce/dist/utils/default-fetcher.js
var default_fetcher = __webpack_require__(663);
;// CONCATENATED MODULE: ../packages/commerce/dist/product/use-search.js


const fetcher = default_fetcher/* SWRFetcher */.DO;
const fn = (provider)=>{
    var ref;
    return (ref = provider.products) == null ? void 0 : ref.useSearch;
};
const useSearch = (input)=>{
    const hook = (0,use_hook/* useHook */.dV)(fn);
    return (0,use_hook/* useSWRHook */.Lz)({
        fetcher,
        ...hook
    })(input);
};
/* harmony default export */ const use_search = (useSearch);

;// CONCATENATED MODULE: ../packages/local/dist/product/use-search.js

/* harmony default export */ const product_use_search = (use_search);
const handler = {
    fetchOptions: {
        query: ""
    },
    async fetcher ({ input , options , fetch  }) {},
    useHook: ()=>()=>{
            return {
                data: {
                    products: []
                }
            };
        }
};


/***/ }),

/***/ 8871:
/***/ ((__webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(__webpack_module__, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "W": () => (/* binding */ localProvider)
/* harmony export */ });
/* harmony import */ var _fetcher__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(622);
/* harmony import */ var _cart_use_cart__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6973);
/* harmony import */ var _cart_use_add_item__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9957);
/* harmony import */ var _cart_use_update_item__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6789);
/* harmony import */ var _cart_use_remove_item__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7260);
/* harmony import */ var _customer_use_customer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6999);
/* harmony import */ var _product_use_search__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4262);
/* harmony import */ var _auth_use_login__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2428);
/* harmony import */ var _auth_use_logout__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6667);
/* harmony import */ var _auth_use_signup__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9557);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_cart_use_cart__WEBPACK_IMPORTED_MODULE_1__]);
_cart_use_cart__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










const localProvider = {
    locale: "en-us",
    cartCookie: "session",
    fetcher: _fetcher__WEBPACK_IMPORTED_MODULE_0__/* .fetcher */ ._,
    cart: {
        useCart: _cart_use_cart__WEBPACK_IMPORTED_MODULE_1__/* .handler */ .y,
        useAddItem: _cart_use_add_item__WEBPACK_IMPORTED_MODULE_2__/* .handler */ .y,
        useUpdateItem: _cart_use_update_item__WEBPACK_IMPORTED_MODULE_3__/* .handler */ .y,
        useRemoveItem: _cart_use_remove_item__WEBPACK_IMPORTED_MODULE_4__/* .handler */ .y
    },
    customer: {
        useCustomer: _customer_use_customer__WEBPACK_IMPORTED_MODULE_5__/* .handler */ .y
    },
    products: {
        useSearch: _product_use_search__WEBPACK_IMPORTED_MODULE_6__/* .handler */ .y
    },
    auth: {
        useLogin: _auth_use_login__WEBPACK_IMPORTED_MODULE_7__/* .handler */ .y,
        useLogout: _auth_use_logout__WEBPACK_IMPORTED_MODULE_8__/* .handler */ .y,
        useSignup: _auth_use_signup__WEBPACK_IMPORTED_MODULE_9__/* .handler */ .y
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;