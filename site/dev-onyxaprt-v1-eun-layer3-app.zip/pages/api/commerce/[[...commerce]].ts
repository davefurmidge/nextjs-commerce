import commerce from '@lib/api/commerce'
import endpoints from '@framework/api/endpoints'

// export const config = {
//   runtime: 'experimental-edge',
// }

export default endpoints(commerce)
