import { getCommerceApi } from '@framework/api'
export default getCommerceApi()
