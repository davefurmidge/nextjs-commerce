// Declarations for modules without types
declare module 'next-themes'
