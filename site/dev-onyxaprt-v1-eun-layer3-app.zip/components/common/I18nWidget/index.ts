export { default } from './I18nWidget'
