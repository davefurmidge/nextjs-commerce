export { default } from './SEO'
