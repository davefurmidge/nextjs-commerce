export { default } from './MenuSidebarView'
export interface Link {
  href: string
  label: string
}
