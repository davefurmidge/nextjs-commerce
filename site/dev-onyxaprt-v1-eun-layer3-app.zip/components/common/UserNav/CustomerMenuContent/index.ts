export { default } from './CustomerMenuContent'
