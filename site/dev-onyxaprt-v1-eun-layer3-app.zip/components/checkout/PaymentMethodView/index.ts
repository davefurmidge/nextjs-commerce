export { default } from './PaymentMethodView'
